<?php
/**
 * File Handler Class
 *
 * @package Figma_WP_Converter
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWC_File_Handler {
    
    public static function validate_uploaded_file($file) {
        $errors = array();
        
        // Check file size (10MB limit)
        if ($file['size'] > 10 * 1024 * 1024) {
            $errors[] = 'File size exceeds 10MB limit';
        }
        
        // Check file type
        $allowed_types = array('image/png', 'image/jpeg', 'image/jpg');
        if (!in_array($file['type'], $allowed_types)) {
            $errors[] = 'Invalid file type. Only PNG and JPG files are allowed';
        }
        
        // Check file extension
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_exts = array('png', 'jpg', 'jpeg');
        if (!in_array($file_ext, $allowed_exts)) {
            $errors[] = 'Invalid file extension';
        }
        
        return $errors;
    }
    
    public static function sanitize_filename($filename) {
        // Remove any path info
        $filename = basename($filename);
        
        // Sanitize the filename
        $filename = sanitize_file_name($filename);
        
        return $filename;
    }
    
    public static function create_project_directory($project_id) {
        $project_dir = FWC_UPLOADS_DIR . $project_id . '/';
        
        if (!file_exists($project_dir)) {
            if (!wp_mkdir_p($project_dir)) {
                return false;
            }
            
            // Create screenshots subdirectory
            wp_mkdir_p($project_dir . 'screenshots/');
            
            // Create .htaccess for security
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "<Files *.php>\n";
            $htaccess_content .= "deny from all\n";
            $htaccess_content .= "</Files>\n";
            
            file_put_contents($project_dir . '.htaccess', $htaccess_content);
        }
        
        return $project_dir;
    }
    
    public static function delete_directory($dir) {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            is_dir($path) ? self::delete_directory($path) : unlink($path);
        }
        
        return rmdir($dir);
    }
    
    public static function get_file_url($project_id, $filename) {
        return FWC_UPLOADS_URL . $project_id . '/screenshots/' . $filename;
    }
}
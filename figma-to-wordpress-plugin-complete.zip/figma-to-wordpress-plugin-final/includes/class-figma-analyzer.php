<?php
/**
 * Figma Analyzer Class
 *
 * @package Figma_WP_Converter
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWC_Figma_Analyzer {
    
    private $screenshots;
    private $project_data;
    private $ai_analyzer;
    private $figma_mcp;
    
    public function __construct($screenshots, $project_data) {
        $this->screenshots = $screenshots;
        $this->project_data = $project_data;
        
        // Initialize AI analyzer
        $this->ai_analyzer = new FWC_AI_Analyzer($screenshots, $project_data);
        
        // Initialize Figma MCP if URL provided
        if (!empty($project_data['figma_url'])) {
            $this->figma_mcp = new FWC_Figma_MCP($project_data['figma_url']);
        }
    }
    
    public function analyze() {
        $results = array(
            'ai_analysis' => null,
            'figma_data' => null,
            'cross_validation' => null,
            'final_analysis' => null,
            'accuracy_score' => 0,
            'status' => 'success'
        );
        
        // Step 0: Sort screenshots in correct order (nav, hero, 1-7, footer)
        $this->screenshots = $this->sort_screenshots($this->screenshots);
        
        // Step 1: Run AI analysis on screenshots
        $ai_result = $this->ai_analyzer->analyze();
        if (!$ai_result['success']) {
            return array(
                'success' => false,
                'message' => 'AI analysis failed: ' . $ai_result['message'],
                'data' => null
            );
        }
        $results['ai_analysis'] = $ai_result['data'];
        
        // Step 2: Extract Figma data if available
        if ($this->figma_mcp) {
            $figma_result = $this->figma_mcp->extract_design_data();
            if ($figma_result['success']) {
                $results['figma_data'] = $figma_result['data'];
                
                // Step 3: Cross-validate AI analysis with Figma data
                if (get_option('enable_cross_validation', true)) {
                    $validation = $this->figma_mcp->cross_validate_with_ai(
                        $results['figma_data'],
                        $results['ai_analysis']
                    );
                    $results['cross_validation'] = $validation;
                    $results['accuracy_score'] = $validation['overall_accuracy'];
                }
            } else {
                $results['status'] = 'partial';
                $results['figma_error'] = $figma_result['message'];
            }
        }
        
        // Step 4: Generate final analysis
        $results['final_analysis'] = $this->generate_final_analysis(
            $results['ai_analysis'],
            $results['figma_data'],
            $results['cross_validation']
        );
        
        return array(
            'success' => true,
            'message' => 'Analysis completed successfully',
            'data' => $results
        );
    }
    
    /**
     * Generate final analysis combining AI and Figma data
     */
    private function generate_final_analysis($ai_analysis, $figma_data, $validation) {
        $final = $ai_analysis; // Start with AI analysis
        
        if ($figma_data && $validation) {
            // Override AI analysis with Figma data where validation score is high
            if (isset($validation['color_accuracy']) && $validation['color_accuracy'] > 85) {
                $final['design_system']['colors'] = $figma_data['design_tokens']['colors'];
            }
            
            if (isset($validation['typography_accuracy']) && $validation['typography_accuracy'] > 85) {
                $final['design_system']['typography'] = $figma_data['design_tokens']['typography'];
            }
            
            // Add Figma-specific data
            $final['figma_assets'] = $figma_data['assets'] ?? array();
            $final['figma_layout'] = $figma_data['layout_structure'] ?? array();
        }
        
        return $final;
    }
    
    /**
     * Sort screenshots in the correct order: nav, hero, 1-7, footer
     */
    private function sort_screenshots($screenshots) {
        if (empty($screenshots)) {
            return $screenshots;
        }
        
        // Add order index to each screenshot
        foreach ($screenshots as $index => &$screenshot) {
            $filename = strtolower(pathinfo($screenshot['name'], PATHINFO_FILENAME));
            
            if ($filename === 'nav') {
                $screenshot['sort_order'] = 1;
            } elseif ($filename === 'hero') {
                $screenshot['sort_order'] = 2;
            } elseif ($filename === 'footer') {
                $screenshot['sort_order'] = 9999; // Always last
            } elseif (preg_match('/^[0-9]+$/', $filename)) {
                // Numbered sections: 1.png, 2.png, 10.png, etc.
                $screenshot['sort_order'] = 2 + intval($filename); // Start after hero (2)
            } else {
                // Other named sections go after numbered but before footer
                $screenshot['sort_order'] = 8000;
            }
        }
        
        // Sort by order index
        usort($screenshots, function($a, $b) {
            return $a['sort_order'] - $b['sort_order'];
        });
        
        // Remove the temporary sort_order field
        foreach ($screenshots as &$screenshot) {
            unset($screenshot['sort_order']);
        }
        
        return $screenshots;
    }
    
    private function analyze_screenshot($screenshot, $index) {
        // Basic screenshot analysis
        $section = array(
            'index' => $index,
            'name' => $screenshot['name'],
            'type' => $this->detect_section_type($screenshot['name']),
            'elements' => array(
                'headings' => true,
                'text' => true,
                'buttons' => true,
                'images' => true
            ),
            'layout' => 'default'
        );
        
        return $section;
    }
    
    private function detect_section_type($filename) {
        $filename = strtolower(pathinfo($filename, PATHINFO_FILENAME));
        
        // Navigation section
        if ($filename === 'nav' || strpos($filename, 'navigation') !== false || strpos($filename, 'navbar') !== false) {
            return 'navigation';
        }
        
        // Hero section
        elseif ($filename === 'hero' || strpos($filename, 'header') !== false) {
            return 'hero';
        }
        
        // Footer section
        elseif ($filename === 'footer') {
            return 'footer';
        }
        
        // Numbered sections (1.png, 2.png, 10.png, etc.)
        elseif (preg_match('/^[0-9]+$/', $filename)) {
            $section_number = intval($filename);
            // Map numbers to likely section types (with fallback for higher numbers)
            switch ($section_number) {
                case 1:
                    return 'services';
                case 2:
                    return 'about';
                case 3:
                    return 'features';
                case 4:
                    return 'testimonials';
                case 5:
                    return 'pricing';
                case 6:
                    return 'contact';
                case 7:
                    return 'gallery';
                case 8:
                    return 'team';
                case 9:
                    return 'blog';
                case 10:
                    return 'faq';
                default:
                    // For sections 11+ just call them content with the number
                    return 'content';
            }
        }
        
        // Named sections
        elseif (strpos($filename, 'service') !== false || strpos($filename, 'feature') !== false) {
            return 'services';
        } elseif (strpos($filename, 'about') !== false || strpos($filename, 'story') !== false) {
            return 'about';
        } elseif (strpos($filename, 'pricing') !== false || strpos($filename, 'plan') !== false) {
            return 'pricing';
        } elseif (strpos($filename, 'testimonial') !== false || strpos($filename, 'review') !== false) {
            return 'testimonials';
        } elseif (strpos($filename, 'contact') !== false) {
            return 'contact';
        } elseif (strpos($filename, 'gallery') !== false || strpos($filename, 'portfolio') !== false) {
            return 'gallery';
        } else {
            return 'content';
        }
    }
}
<?php
/**
 * AI-Powered Design Analyzer Class
 *
 * @package Figma_WP_Converter
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWC_AI_Analyzer {
    
    private $api_provider;
    private $api_key;
    private $screenshots;
    private $project_data;
    
    public function __construct($screenshots, $project_data) {
        $this->screenshots = $screenshots;
        $this->project_data = $project_data;
        $this->api_provider = get_option('fwc_api_provider', 'openai');
        $api_key = get_option('fwc_api_key', '');
        $this->api_key = !empty($api_key) ? base64_decode($api_key) : '';
    }
    
    /**
     * Analyze screenshots using AI Vision API
     */
    public function analyze() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key not configured. Please set up your AI provider in Settings.',
                'data' => null
            );
        }
        
        $analysis_results = array(
            'design_system' => array(),
            'sections' => array(),
            'global_styles' => array(),
            'components' => array()
        );
        
        // Step 1: Analyze each screenshot individually
        foreach ($this->screenshots as $index => $screenshot) {
            $section_analysis = $this->analyze_screenshot($screenshot, $index);
            if ($section_analysis) {
                $analysis_results['sections'][] = $section_analysis;
            }
        }
        
        // Step 2: Extract global design system
        $analysis_results['design_system'] = $this->extract_design_system($analysis_results['sections']);
        
        // Step 3: Generate structured theme data
        $theme_structure = $this->generate_theme_structure($analysis_results);
        
        return array(
            'success' => true,
            'message' => 'Design analysis completed successfully',
            'data' => $theme_structure
        );
    }
    
    /**
     * Analyze individual screenshot with AI
     */
    private function analyze_screenshot($screenshot, $index) {
        $prompt = $this->get_analysis_prompt($screenshot['name'], $index);
        
        switch ($this->api_provider) {
            case 'openrouter':
                return $this->analyze_with_openrouter($screenshot['path'], $prompt);
            case 'openai':
                return $this->analyze_with_openai($screenshot['path'], $prompt);
            case 'claude':
                return $this->analyze_with_claude($screenshot['path'], $prompt);
            case 'gemini':
                return $this->analyze_with_gemini($screenshot['path'], $prompt);
            default:
                return $this->fallback_analysis($screenshot, $index);
        }
    }
    
    /**
     * OpenRouter Vision Analysis (Multiple Models)
     */
    private function analyze_with_openrouter($image_path, $prompt) {
        $image_data = base64_encode(file_get_contents($image_path));
        
        // Get user-selected OpenRouter model
        $selected_model = get_option('fwc_openrouter_model', 'mistralai/pixtral-12b-2409');
        if (empty($selected_model)) {
            $selected_model = 'mistralai/pixtral-12b-2409'; // Default fallback
        }
        
        $request_body = array(
            'model' => $selected_model,
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => array(
                        array(
                            'type' => 'text',
                            'text' => $prompt
                        ),
                        array(
                            'type' => 'image_url',
                            'image_url' => array(
                                'url' => 'data:image/jpeg;base64,' . $image_data,
                                'detail' => 'high'
                            )
                        )
                    )
                )
            ),
            'max_tokens' => 4096
        );
        
        $response = wp_remote_post('https://openrouter.ai/api/v1/chat/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
                'HTTP-Referer' => home_url(), // Required by OpenRouter
                'X-Title' => 'Figma to WordPress Plugin'
            ),
            'body' => json_encode($request_body),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['choices'][0]['message']['content'])) {
            // Parse JSON from response
            $content = $body['choices'][0]['message']['content'];
            $json_match = preg_match('/\{.*\}/s', $content, $matches);
            
            if ($json_match) {
                return json_decode($matches[0], true);
            }
        }
        
        return null;
    }
    
    /**
     * OpenAI GPT-4 Vision Analysis
     */
    private function analyze_with_openai($image_path, $prompt) {
        $image_data = base64_encode(file_get_contents($image_path));
        
        $request_body = array(
            'model' => 'gpt-4-vision-preview',
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => array(
                        array(
                            'type' => 'text',
                            'text' => $prompt
                        ),
                        array(
                            'type' => 'image_url',
                            'image_url' => array(
                                'url' => 'data:image/jpeg;base64,' . $image_data,
                                'detail' => 'high'
                            )
                        )
                    )
                )
            ),
            'max_tokens' => 4096
        );
        
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_body),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['choices'][0]['message']['content'])) {
            // Parse JSON from response
            $content = $body['choices'][0]['message']['content'];
            $json_match = preg_match('/\{.*\}/s', $content, $matches);
            
            if ($json_match) {
                return json_decode($matches[0], true);
            }
        }
        
        return null;
    }
    
    /**
     * Claude 3 Vision Analysis
     */
    private function analyze_with_claude($image_path, $prompt) {
        $image_data = base64_encode(file_get_contents($image_path));
        
        $request_body = array(
            'model' => 'claude-3-opus-20240229',
            'max_tokens' => 4096,
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => array(
                        array(
                            'type' => 'image',
                            'source' => array(
                                'type' => 'base64',
                                'media_type' => 'image/jpeg',
                                'data' => $image_data
                            )
                        ),
                        array(
                            'type' => 'text',
                            'text' => $prompt
                        )
                    )
                )
            )
        );
        
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'headers' => array(
                'x-api-key' => $this->api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_body),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['content'][0]['text'])) {
            $content = $body['content'][0]['text'];
            $json_match = preg_match('/\{.*\}/s', $content, $matches);
            
            if ($json_match) {
                return json_decode($matches[0], true);
            }
        }
        
        return null;
    }
    
    /**
     * Google Gemini Vision Analysis
     */
    private function analyze_with_gemini($image_path, $prompt) {
        $image_data = base64_encode(file_get_contents($image_path));
        
        $request_body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array(
                            'text' => $prompt
                        ),
                        array(
                            'inline_data' => array(
                                'mime_type' => 'image/jpeg',
                                'data' => $image_data
                            )
                        )
                    )
                )
            )
        );
        
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?key=' . $this->api_key;
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($request_body),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $content = $body['candidates'][0]['content']['parts'][0]['text'];
            $json_match = preg_match('/\{.*\}/s', $content, $matches);
            
            if ($json_match) {
                return json_decode($matches[0], true);
            }
        }
        
        return null;
    }
    
    /**
     * Get analysis prompt for AI
     */
    private function get_analysis_prompt($filename, $index) {
        $business_type = $this->project_data['business_type'] ?? 'general';
        
        return "Analyze this design screenshot for a {$business_type} website. This is section {$index} ({$filename}).
        
        Return a detailed JSON analysis with the following structure:
        {
            \"section_type\": \"hero|navigation|services|about|features|testimonials|pricing|contact|footer|content\",
            \"layout\": {
                \"type\": \"full-width|contained|split|grid\",
                \"columns\": number,
                \"spacing\": \"tight|normal|loose\"
            },
            \"colors\": {
                \"primary\": \"#hex\",
                \"secondary\": \"#hex\",
                \"background\": \"#hex\",
                \"text\": \"#hex\",
                \"accent\": \"#hex\"
            },
            \"typography\": {
                \"headings\": {
                    \"family\": \"font-family\",
                    \"weight\": \"weight\",
                    \"size\": \"size-range\"
                },
                \"body\": {
                    \"family\": \"font-family\",
                    \"weight\": \"weight\",
                    \"size\": \"size\"
                }
            },
            \"components\": [
                {
                    \"type\": \"heading|text|button|image|card|form|menu|logo\",
                    \"content\": \"detected text or description\",
                    \"style\": {},
                    \"position\": \"top|center|bottom|left|right\"
                }
            ],
            \"responsive_hints\": {
                \"mobile_layout\": \"stack|hide|resize\",
                \"breakpoints\": []
            }
        }
        
        Be precise with color values, spacing measurements, and component detection. Focus on extracting exact design specifications that can be converted to CSS.";
    }
    
    /**
     * Fallback analysis when no API is available
     */
    private function fallback_analysis($screenshot, $index) {
        // Basic analysis based on filename patterns
        $filename = strtolower($screenshot['name']);
        $section_type = 'content';
        
        if (strpos($filename, 'hero') !== false || $index === 0) {
            $section_type = 'hero';
        } elseif (strpos($filename, 'nav') !== false || strpos($filename, 'header') !== false) {
            $section_type = 'navigation';
        } elseif (strpos($filename, 'service') !== false) {
            $section_type = 'services';
        } elseif (strpos($filename, 'about') !== false) {
            $section_type = 'about';
        } elseif (strpos($filename, 'footer') !== false) {
            $section_type = 'footer';
        }
        
        return array(
            'section_type' => $section_type,
            'layout' => array(
                'type' => 'contained',
                'columns' => 1,
                'spacing' => 'normal'
            ),
            'colors' => array(
                'primary' => '#0073aa',
                'secondary' => '#23282d',
                'background' => '#ffffff',
                'text' => '#333333',
                'accent' => '#0073aa'
            ),
            'typography' => array(
                'headings' => array(
                    'family' => '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                    'weight' => '700',
                    'size' => '2.5rem'
                ),
                'body' => array(
                    'family' => '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                    'weight' => '400',
                    'size' => '16px'
                )
            ),
            'components' => array(),
            'responsive_hints' => array(
                'mobile_layout' => 'stack',
                'breakpoints' => array(768, 1024, 1200)
            )
        );
    }
    
    /**
     * Extract global design system from sections
     */
    private function extract_design_system($sections) {
        $design_system = array(
            'colors' => array(),
            'typography' => array(),
            'spacing' => array(),
            'breakpoints' => array(768, 1024, 1200)
        );
        
        // Aggregate colors from all sections
        $all_colors = array();
        foreach ($sections as $section) {
            if (isset($section['colors'])) {
                foreach ($section['colors'] as $key => $color) {
                    if (!isset($all_colors[$key])) {
                        $all_colors[$key] = array();
                    }
                    $all_colors[$key][] = $color;
                }
            }
        }
        
        // Find most common colors
        foreach ($all_colors as $key => $colors) {
            $color_counts = array_count_values($colors);
            arsort($color_counts);
            $design_system['colors'][$key] = key($color_counts);
        }
        
        // Extract typography
        if (!empty($sections) && isset($sections[0]['typography'])) {
            $design_system['typography'] = $sections[0]['typography'];
        }
        
        return $design_system;
    }
    
    /**
     * Generate theme structure from analysis
     */
    private function generate_theme_structure($analysis_results) {
        return array(
            'design_system' => $analysis_results['design_system'],
            'sections' => $analysis_results['sections'],
            'theme_config' => array(
                'name' => $this->project_data['name'],
                'business_type' => $this->project_data['business_type'],
                'version' => '1.0.0',
                'responsive' => true,
                'custom_colors' => true,
                'custom_fonts' => true
            ),
            'files_to_generate' => array(
                'style.css' => $this->generate_css_from_analysis($analysis_results),
                'index.php' => $this->generate_html_from_analysis($analysis_results),
                'functions.php' => $this->generate_functions_from_analysis($analysis_results)
            )
        );
    }
    
    /**
     * Generate CSS from analysis
     */
    private function generate_css_from_analysis($analysis) {
        $css = array();
        $design_system = $analysis['design_system'];
        
        // CSS Variables
        $css[] = ':root {';
        foreach ($design_system['colors'] as $key => $color) {
            $css[] = "  --color-{$key}: {$color};";
        }
        $css[] = '}';
        
        // Typography
        if (isset($design_system['typography'])) {
            $css[] = 'body {';
            $css[] = "  font-family: {$design_system['typography']['body']['family']};";
            $css[] = "  font-size: {$design_system['typography']['body']['size']};";
            $css[] = "  font-weight: {$design_system['typography']['body']['weight']};";
            $css[] = "  color: var(--color-text);";
            $css[] = '}';
            
            $css[] = 'h1, h2, h3, h4, h5, h6 {';
            $css[] = "  font-family: {$design_system['typography']['headings']['family']};";
            $css[] = "  font-weight: {$design_system['typography']['headings']['weight']};";
            $css[] = '}';
        }
        
        return implode("\n", $css);
    }
    
    /**
     * Generate HTML from analysis
     */
    private function generate_html_from_analysis($analysis) {
        $html = array();
        
        foreach ($analysis['sections'] as $section) {
            $section_class = 'section-' . $section['section_type'];
            $html[] = "<section class=\"{$section_class}\">";
            
            if (isset($section['components'])) {
                foreach ($section['components'] as $component) {
                    $html[] = $this->generate_component_html($component);
                }
            }
            
            $html[] = "</section>";
        }
        
        return implode("\n", $html);
    }
    
    /**
     * Generate component HTML
     */
    private function generate_component_html($component) {
        switch ($component['type']) {
            case 'heading':
                return "<h2>{$component['content']}</h2>";
            case 'text':
                return "<p>{$component['content']}</p>";
            case 'button':
                return "<a href=\"#\" class=\"btn\">{$component['content']}</a>";
            case 'image':
                return "<img src=\"placeholder.jpg\" alt=\"{$component['content']}\" />";
            default:
                return "<div>{$component['content']}</div>";
        }
    }
    
    /**
     * Generate functions.php from analysis
     */
    private function generate_functions_from_analysis($analysis) {
        // Generate theme functions based on detected features
        return "<?php\n// Theme functions generated from design analysis\n";
    }
}
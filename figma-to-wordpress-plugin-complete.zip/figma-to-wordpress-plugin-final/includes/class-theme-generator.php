<?php
/**
 * Theme Generator Class
 *
 * @package Figma_WP_Converter
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWC_Theme_Generator {
    
    private $project_data;
    private $project_dir;
    private $analyzer;
    
    public function __construct($project_data, $project_dir) {
        $this->project_data = $project_data;
        $this->project_dir = $project_dir;
    }
    
    public function generate_theme() {
        try {
            // Create theme directory
            $theme_name = sanitize_title($this->project_data['name']);
            $theme_dir = $this->project_dir . 'theme/';
            
            if (!wp_mkdir_p($theme_dir)) {
                return array(
                    'success' => false,
                    'message' => 'Failed to create theme directory',
                    'errors' => array('Directory creation failed')
                );
            }
            
            // Generate theme files
            $this->generate_style_css($theme_dir);
            $this->generate_index_php($theme_dir);
            $this->generate_functions_php($theme_dir);
            $this->generate_header_php($theme_dir);
            $this->generate_footer_php($theme_dir);
            $this->generate_readme($theme_dir);
            
            // Create theme ZIP
            $zip_path = $this->create_theme_zip($theme_dir, $theme_name);
            
            if (!$zip_path) {
                return array(
                    'success' => false,
                    'message' => 'Failed to create theme ZIP file',
                    'errors' => array('ZIP creation failed')
                );
            }
            
            $download_url = str_replace(ABSPATH, home_url('/'), $zip_path);
            
            return array(
                'success' => true,
                'message' => 'Theme generated successfully',
                'theme_path' => $zip_path,
                'download_url' => $download_url,
                'preview_url' => null
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => 'Theme generation failed: ' . $e->getMessage(),
                'errors' => array($e->getMessage())
            );
        }
    }
    
    private function generate_style_css($theme_dir) {
        $theme_name = $this->project_data['name'];
        $business_type = $this->project_data['business_type'];
        
        $css_content = "/*
Theme Name: {$theme_name}
Description: A custom WordPress theme generated from Figma design for {$business_type} business.
Author: Figma to WordPress Converter
Version: 1.0.0
License: GPL v2 or later
*/

/* Reset and base styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Header */
.site-header {
    background: #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    padding: 1rem 0;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Navigation */
.main-nav ul {
    list-style: none;
    display: flex;
    gap: 2rem;
}

.main-nav a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
}

/* Hero Section */
.hero-section {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 6rem 0;
    text-align: center;
}

.hero-title {
    font-size: clamp(2rem, 5vw, 4rem);
    margin-bottom: 1rem;
    font-weight: bold;
}

.hero-subtitle {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

/* Buttons */
.btn {
    display: inline-block;
    padding: 12px 30px;
    background: #007cba;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: 500;
    transition: background 0.3s ease;
}

.btn:hover {
    background: #005a87;
}

.btn-outline {
    background: transparent;
    border: 2px solid white;
}

.btn-outline:hover {
    background: white;
    color: #333;
}

/* Sections */
.section {
    padding: 4rem 0;
}

.section-title {
    font-size: 2.5rem;
    text-align: center;
    margin-bottom: 3rem;
}

/* Services */
.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.service-card {
    background: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    text-align: center;
}

/* Footer */
.site-footer {
    background: #333;
    color: white;
    padding: 3rem 0 1rem;
}

.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
}

/* Responsive */
@media (max-width: 768px) {
    .header-content {
        flex-direction: column;
        gap: 1rem;
    }
    
    .main-nav ul {
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .hero-section {
        padding: 4rem 0;
    }
}";
        
        file_put_contents($theme_dir . 'style.css', $css_content);
    }
    
    private function generate_index_php($theme_dir) {
        $content = "<?php get_header(); ?>

<main class=\"site-main\">
    <!-- Hero Section -->
    <section class=\"hero-section\">
        <div class=\"container\">
            <h1 class=\"hero-title\"><?php echo get_bloginfo('name'); ?></h1>
            <p class=\"hero-subtitle\"><?php echo get_bloginfo('description'); ?></p>
            <div class=\"hero-buttons\">
                <a href=\"#services\" class=\"btn\">Get Started</a>
                <a href=\"#about\" class=\"btn btn-outline\">Learn More</a>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id=\"services\" class=\"section\">
        <div class=\"container\">
            <h2 class=\"section-title\">Our Services</h2>
            <div class=\"services-grid\">
                <div class=\"service-card\">
                    <h3>Service One</h3>
                    <p>Description of your first service offering.</p>
                </div>
                <div class=\"service-card\">
                    <h3>Service Two</h3>
                    <p>Description of your second service offering.</p>
                </div>
                <div class=\"service-card\">
                    <h3>Service Three</h3>
                    <p>Description of your third service offering.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id=\"about\" class=\"section\">
        <div class=\"container\">
            <h2 class=\"section-title\">About Us</h2>
            <p>Add your about content here. This theme was generated from your Figma design.</p>
        </div>
    </section>
</main>

<?php get_footer(); ?>";
        
        file_put_contents($theme_dir . 'index.php', $content);
    }
    
    private function generate_functions_php($theme_dir) {
        $content = "<?php
/**
 * Theme functions and definitions
 */

// Theme setup
function theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    register_nav_menus(array(
        'primary' => 'Primary Menu',
    ));
}
add_action('after_setup_theme', 'theme_setup');

// Enqueue styles and scripts
function theme_scripts() {
    wp_enqueue_style('theme-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'theme_scripts');

// Register widget areas
function theme_widgets_init() {
    register_sidebar(array(
        'name'          => 'Sidebar',
        'id'            => 'sidebar-1',
        'description'   => 'Add widgets here.',
        'before_widget' => '<section id=\"%1\$s\" class=\"widget %2\$s\">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class=\"widget-title\">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'theme_widgets_init');
?>";
        
        file_put_contents($theme_dir . 'functions.php', $content);
    }
    
    private function generate_header_php($theme_dir) {
        $content = "<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset=\"<?php bloginfo('charset'); ?>\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id=\"page\" class=\"site\">
    <header id=\"masthead\" class=\"site-header\">
        <div class=\"container header-content\">
            <div class=\"site-branding\">
                <h1 class=\"site-title\">
                    <a href=\"<?php echo esc_url(home_url('/')); ?>\" rel=\"home\">
                        <?php bloginfo('name'); ?>
                    </a>
                </h1>
            </div>

            <nav id=\"site-navigation\" class=\"main-nav\">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',
                ));
                ?>
            </nav>
        </div>
    </header>";
        
        file_put_contents($theme_dir . 'header.php', $content);
    }
    
    private function generate_footer_php($theme_dir) {
        $content = "    <footer id=\"colophon\" class=\"site-footer\">
        <div class=\"container\">
            <div class=\"footer-content\">
                <div class=\"footer-info\">
                    <h3><?php bloginfo('name'); ?></h3>
                    <p><?php bloginfo('description'); ?></p>
                </div>
                <div class=\"footer-links\">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href=\"<?php echo home_url('/'); ?>\">Home</a></li>
                        <li><a href=\"<?php echo home_url('/about'); ?>\">About</a></li>
                        <li><a href=\"<?php echo home_url('/contact'); ?>\">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class=\"footer-bottom\">
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
</div>

<?php wp_footer(); ?>
</body>
</html>";
        
        file_put_contents($theme_dir . 'footer.php', $content);
    }
    
    private function generate_readme($theme_dir) {
        $theme_name = $this->project_data['name'];
        $content = "# {$theme_name} WordPress Theme

This theme was generated from your Figma design using the Figma to WordPress converter plugin.

## Installation

1. Upload the theme to your WordPress site
2. Go to Appearance > Themes
3. Activate the theme
4. Customize using Appearance > Customize

## Customization

- Add your logo in Appearance > Customize > Site Identity
- Create menus in Appearance > Menus
- Add widgets in Appearance > Widgets
- Update content to match your design

## Support

This theme was automatically generated. For customizations, consider hiring a WordPress developer.
";
        
        file_put_contents($theme_dir . 'README.md', $content);
    }
    
    private function create_theme_zip($theme_dir, $theme_name) {
        $zip_filename = sanitize_file_name($theme_name) . '-theme.zip';
        $zip_path = $this->project_dir . $zip_filename;
        
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE) !== TRUE) {
            return false;
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($theme_dir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $name => $file) {
            if (!$file->isDir()) {
                $file_path = $file->getRealPath();
                $relative_path = substr($file_path, strlen($theme_dir));
                $zip->addFile($file_path, $relative_path);
            }
        }
        
        $zip->close();
        
        return $zip_path;
    }
}
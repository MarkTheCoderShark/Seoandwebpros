<?php
/**
 * Figma MCP Integration Class
 *
 * @package Figma_WP_Converter
 */

if (!defined('ABSPATH')) {
    exit;
}

class FWC_Figma_MCP {
    
    private $figma_url;
    private $file_id;
    private $node_id;
    private $figma_token;
    
    public function __construct($figma_url) {
        $this->figma_url = $figma_url;
        $this->parse_figma_url();
        $this->figma_token = get_option('fwc_figma_token', '');
    }
    
    /**
     * Parse Figma URL to extract file ID and node ID
     */
    private function parse_figma_url() {
        if (preg_match('/figma\.com\/design\/([^\/]+)/', $this->figma_url, $matches)) {
            $this->file_id = $matches[1];
        } elseif (preg_match('/figma\.com\/file\/([^\/]+)/', $this->figma_url, $matches)) {
            $this->file_id = $matches[1];
        }
        
        // Extract node ID if present
        if (preg_match('/node-id=([^&]+)/', $this->figma_url, $matches)) {
            $this->node_id = urldecode($matches[1]);
        }
    }
    
    /**
     * Connect to Figma MCP server and extract design data
     */
    public function extract_design_data() {
        if (empty($this->file_id)) {
            return array(
                'success' => false,
                'message' => 'Invalid Figma URL - could not extract file ID',
                'data' => null
            );
        }
        
        if (empty($this->figma_token)) {
            return array(
                'success' => false,
                'message' => 'Figma access token not configured. Please add your Figma token in Settings.',
                'data' => null
            );
        }
        
        // Try MCP server first, fallback to direct API
        $mcp_result = $this->connect_to_mcp_server();
        
        if ($mcp_result['success']) {
            return $mcp_result;
        }
        
        // Fallback to direct Figma API
        return $this->connect_to_figma_api();
    }
    
    /**
     * Connect to Figma MCP server
     */
    private function connect_to_mcp_server() {
        // Check if MCP server is running (typically on localhost:3000)
        $mcp_endpoints = array(
            'http://localhost:3000',
            'http://127.0.0.1:3000',
            'http://localhost:8080'
        );
        
        foreach ($mcp_endpoints as $endpoint) {
            $result = $this->try_mcp_endpoint($endpoint);
            if ($result['success']) {
                return $result;
            }
        }
        
        return array(
            'success' => false,
            'message' => 'Could not connect to Figma MCP server',
            'data' => null
        );
    }
    
    /**
     * Try connecting to specific MCP endpoint
     */
    private function try_mcp_endpoint($endpoint) {
        $mcp_request = array(
            'method' => 'figma.getFile',
            'params' => array(
                'fileId' => $this->file_id,
                'nodeId' => $this->node_id,
                'includeStyles' => true,
                'includeComponents' => true,
                'depth' => 3
            )
        );
        
        $response = wp_remote_post($endpoint . '/mcp/figma', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->figma_token
            ),
            'body' => json_encode($mcp_request),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['result'])) {
            return array(
                'success' => true,
                'message' => 'Successfully extracted design data via MCP',
                'data' => $this->process_figma_data($body['result']),
                'source' => 'mcp'
            );
        }
        
        return array('success' => false, 'message' => 'MCP server error');
    }
    
    /**
     * Connect directly to Figma API
     */
    private function connect_to_figma_api() {
        $api_url = "https://api.figma.com/v1/files/{$this->file_id}";
        
        if ($this->node_id) {
            $api_url .= "?ids=" . urlencode($this->node_id);
        }
        
        $response = wp_remote_get($api_url, array(
            'headers' => array(
                'X-Figma-Token' => $this->figma_token
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to connect to Figma API: ' . $response->get_error_message(),
                'data' => null
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['document'])) {
            // Get styles
            $styles = $this->get_figma_styles();
            
            return array(
                'success' => true,
                'message' => 'Successfully extracted design data via Figma API',
                'data' => $this->process_figma_data($body, $styles),
                'source' => 'api'
            );
        }
        
        return array(
            'success' => false,
            'message' => 'Failed to extract data from Figma API',
            'data' => null
        );
    }
    
    /**
     * Get Figma styles (colors, typography, etc.)
     */
    private function get_figma_styles() {
        $styles_url = "https://api.figma.com/v1/files/{$this->file_id}/styles";
        
        $response = wp_remote_get($styles_url, array(
            'headers' => array(
                'X-Figma-Token' => $this->figma_token
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return isset($body['meta']['styles']) ? $body['meta']['styles'] : array();
    }
    
    /**
     * Process Figma data into standardized format
     */
    private function process_figma_data($figma_data, $styles = array()) {
        $processed = array(
            'design_tokens' => array(
                'colors' => array(),
                'typography' => array(),
                'spacing' => array(),
                'components' => array()
            ),
            'layout_structure' => array(),
            'assets' => array()
        );
        
        // Extract design tokens
        $processed['design_tokens'] = $this->extract_design_tokens($figma_data, $styles);
        
        // Extract layout structure
        $processed['layout_structure'] = $this->extract_layout_structure($figma_data);
        
        // Extract assets (images, icons)
        $processed['assets'] = $this->extract_assets($figma_data);
        
        return $processed;
    }
    
    /**
     * Extract design tokens from Figma data
     */
    private function extract_design_tokens($figma_data, $styles) {
        $tokens = array(
            'colors' => array(),
            'typography' => array(),
            'spacing' => array(),
            'effects' => array()
        );
        
        // Process styles
        foreach ($styles as $style) {
            switch ($style['styleType']) {
                case 'FILL':
                    if (isset($style['fills'][0]['color'])) {
                        $color = $style['fills'][0]['color'];
                        $hex = $this->rgba_to_hex($color);
                        $tokens['colors'][$style['name']] = $hex;
                    }
                    break;
                    
                case 'TEXT':
                    if (isset($style['fontFamily'])) {
                        $tokens['typography'][$style['name']] = array(
                            'fontFamily' => $style['fontFamily'],
                            'fontWeight' => $style['fontWeight'] ?? 400,
                            'fontSize' => $style['fontSize'] ?? 16,
                            'lineHeight' => $style['lineHeight'] ?? '1.5'
                        );
                    }
                    break;
                    
                case 'EFFECT':
                    $tokens['effects'][$style['name']] = $style['effects'] ?? array();
                    break;
            }
        }
        
        // Extract colors from document nodes
        $this->extract_colors_from_nodes($figma_data['document'], $tokens['colors']);
        
        return $tokens;
    }
    
    /**
     * Extract layout structure
     */
    private function extract_layout_structure($figma_data) {
        $structure = array();
        
        if (isset($figma_data['document']['children'])) {
            foreach ($figma_data['document']['children'] as $page) {
                if ($page['type'] === 'CANVAS' && isset($page['children'])) {
                    foreach ($page['children'] as $frame) {
                        $structure[] = $this->process_frame($frame);
                    }
                }
            }
        }
        
        return $structure;
    }
    
    /**
     * Process individual frame/section
     */
    private function process_frame($frame) {
        return array(
            'id' => $frame['id'],
            'name' => $frame['name'],
            'type' => $frame['type'],
            'width' => $frame['absoluteBoundingBox']['width'] ?? 0,
            'height' => $frame['absoluteBoundingBox']['height'] ?? 0,
            'x' => $frame['absoluteBoundingBox']['x'] ?? 0,
            'y' => $frame['absoluteBoundingBox']['y'] ?? 0,
            'backgroundColor' => $this->extract_background_color($frame),
            'children' => $this->process_children($frame['children'] ?? array()),
            'constraints' => $frame['constraints'] ?? array(),
            'layoutMode' => $frame['layoutMode'] ?? null,
            'paddingLeft' => $frame['paddingLeft'] ?? 0,
            'paddingRight' => $frame['paddingRight'] ?? 0,
            'paddingTop' => $frame['paddingTop'] ?? 0,
            'paddingBottom' => $frame['paddingBottom'] ?? 0,
            'itemSpacing' => $frame['itemSpacing'] ?? 0
        );
    }
    
    /**
     * Process child elements
     */
    private function process_children($children) {
        $processed_children = array();
        
        foreach ($children as $child) {
            $processed_child = array(
                'id' => $child['id'],
                'name' => $child['name'],
                'type' => $child['type'],
                'width' => $child['absoluteBoundingBox']['width'] ?? 0,
                'height' => $child['absoluteBoundingBox']['height'] ?? 0,
                'x' => $child['absoluteBoundingBox']['x'] ?? 0,
                'y' => $child['absoluteBoundingBox']['y'] ?? 0
            );
            
            // Add type-specific properties
            switch ($child['type']) {
                case 'TEXT':
                    $processed_child['content'] = $child['characters'] ?? '';
                    $processed_child['typography'] = $child['style'] ?? array();
                    break;
                    
                case 'RECTANGLE':
                case 'ELLIPSE':
                case 'POLYGON':
                    $processed_child['fills'] = $child['fills'] ?? array();
                    $processed_child['strokes'] = $child['strokes'] ?? array();
                    break;
                    
                case 'FRAME':
                case 'GROUP':
                    $processed_child['children'] = $this->process_children($child['children'] ?? array());
                    break;
            }
            
            $processed_children[] = $processed_child;
        }
        
        return $processed_children;
    }
    
    /**
     * Extract assets (images, icons)
     */
    private function extract_assets($figma_data) {
        $assets = array();
        
        // This would extract image references and export URLs
        // Implementation depends on specific Figma API endpoints
        
        return $assets;
    }
    
    /**
     * Extract colors from document nodes recursively
     */
    private function extract_colors_from_nodes($node, &$colors) {
        if (isset($node['fills'])) {
            foreach ($node['fills'] as $fill) {
                if ($fill['type'] === 'SOLID' && isset($fill['color'])) {
                    $hex = $this->rgba_to_hex($fill['color']);
                    if (!in_array($hex, $colors)) {
                        $colors[] = $hex;
                    }
                }
            }
        }
        
        if (isset($node['children'])) {
            foreach ($node['children'] as $child) {
                $this->extract_colors_from_nodes($child, $colors);
            }
        }
    }
    
    /**
     * Extract background color from frame
     */
    private function extract_background_color($frame) {
        if (isset($frame['backgroundColor'])) {
            return $this->rgba_to_hex($frame['backgroundColor']);
        }
        
        if (isset($frame['fills'][0]['color'])) {
            return $this->rgba_to_hex($frame['fills'][0]['color']);
        }
        
        return '#ffffff';
    }
    
    /**
     * Convert RGBA to hex
     */
    private function rgba_to_hex($rgba) {
        $r = round($rgba['r'] * 255);
        $g = round($rgba['g'] * 255);  
        $b = round($rgba['b'] * 255);
        
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
    
    /**
     * Cross-validate with AI analysis
     */
    public function cross_validate_with_ai($figma_data, $ai_analysis) {
        $validation_results = array(
            'color_accuracy' => 0,
            'typography_accuracy' => 0,
            'layout_accuracy' => 0,
            'overall_accuracy' => 0,
            'discrepancies' => array(),
            'recommendations' => array()
        );
        
        // Compare colors
        $validation_results['color_accuracy'] = $this->validate_colors(
            $figma_data['design_tokens']['colors'],
            $ai_analysis['design_system']['colors']
        );
        
        // Compare typography
        $validation_results['typography_accuracy'] = $this->validate_typography(
            $figma_data['design_tokens']['typography'],
            $ai_analysis['design_system']['typography']
        );
        
        // Compare layout structure
        $validation_results['layout_accuracy'] = $this->validate_layout(
            $figma_data['layout_structure'],
            $ai_analysis['sections']
        );
        
        // Calculate overall accuracy
        $validation_results['overall_accuracy'] = (
            $validation_results['color_accuracy'] + 
            $validation_results['typography_accuracy'] + 
            $validation_results['layout_accuracy']
        ) / 3;
        
        return $validation_results;
    }
    
    /**
     * Validate colors between Figma and AI analysis
     */
    private function validate_colors($figma_colors, $ai_colors) {
        $matches = 0;
        $total = max(count($figma_colors), count($ai_colors), 1);
        
        foreach ($ai_colors as $key => $ai_color) {
            if (isset($figma_colors[$key])) {
                $similarity = $this->color_similarity($figma_colors[$key], $ai_color);
                if ($similarity > 0.8) {
                    $matches++;
                }
            }
        }
        
        return ($matches / $total) * 100;
    }
    
    /**
     * Calculate color similarity
     */
    private function color_similarity($color1, $color2) {
        // Convert hex to RGB and calculate similarity
        $rgb1 = sscanf($color1, "#%02x%02x%02x");
        $rgb2 = sscanf($color2, "#%02x%02x%02x");
        
        $distance = sqrt(
            pow($rgb1[0] - $rgb2[0], 2) +
            pow($rgb1[1] - $rgb2[1], 2) +
            pow($rgb1[2] - $rgb2[2], 2)
        );
        
        return 1 - ($distance / 441.67); // 441.67 is max distance
    }
    
    /**
     * Validate typography
     */
    private function validate_typography($figma_typography, $ai_typography) {
        // Compare font families, weights, sizes
        // Implementation would check similarity between Figma and AI detected typography
        return 85; // Placeholder
    }
    
    /**
     * Validate layout structure  
     */
    private function validate_layout($figma_layout, $ai_sections) {
        // Compare section count, positioning, hierarchy
        // Implementation would analyze layout similarities
        return 80; // Placeholder
    }
}
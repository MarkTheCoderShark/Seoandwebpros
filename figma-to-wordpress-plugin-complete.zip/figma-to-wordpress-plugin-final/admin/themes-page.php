<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get generated themes from database
global $wpdb;
$table_name = $wpdb->prefix . 'figma_wp_projects';

// Check if table exists
$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;

if ($table_exists) {
    $projects = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 20");
} else {
    $projects = array();
}
?>

<div class="wrap figma-wp-themes">
    <h1><?php _e('Generated Themes', 'figma-wp-converter'); ?></h1>
    
    <?php if (empty($projects)): ?>
        <div class="no-themes-message">
            <div class="no-themes-content">
                <div class="no-themes-icon">🎨</div>
                <h2><?php _e('No themes generated yet', 'figma-wp-converter'); ?></h2>
                <p><?php _e('Once you generate themes using the converter, they\'ll appear here for download and management.', 'figma-wp-converter'); ?></p>
                <a href="<?php echo admin_url('admin.php?page=figma-wp-converter'); ?>" class="button button-primary">
                    <?php _e('Generate Your First Theme', 'figma-wp-converter'); ?>
                </a>
            </div>
        </div>
    <?php else: ?>
        
        <div class="themes-header">
            <p><?php printf(_n('You have generated %d theme.', 'You have generated %d themes.', count($projects), 'figma-wp-converter'), count($projects)); ?></p>
            <a href="<?php echo admin_url('admin.php?page=figma-wp-converter'); ?>" class="button button-primary">
                <?php _e('Generate New Theme', 'figma-wp-converter'); ?>
            </a>
        </div>

        <div class="themes-grid">
            <?php foreach ($projects as $project): ?>
                <div class="theme-card">
                    <div class="theme-card-header">
                        <h3 class="theme-title"><?php echo esc_html($project->project_name); ?></h3>
                        <span class="theme-status status-<?php echo esc_attr($project->status); ?>">
                            <?php echo esc_html(ucfirst($project->status)); ?>
                        </span>
                    </div>
                    
                    <div class="theme-card-content">
                        <div class="theme-meta">
                            <div class="meta-item">
                                <strong><?php _e('Business Type:', 'figma-wp-converter'); ?></strong>
                                <?php echo esc_html($project->business_type ?: 'Not specified'); ?>
                            </div>
                            <div class="meta-item">
                                <strong><?php _e('Created:', 'figma-wp-converter'); ?></strong>
                                <?php echo date('M j, Y g:i A', strtotime($project->created_at)); ?>
                            </div>
                            <div class="meta-item">
                                <strong><?php _e('Project ID:', 'figma-wp-converter'); ?></strong>
                                <code><?php echo esc_html($project->project_id); ?></code>
                            </div>
                        </div>
                        
                        <?php if ($project->status === 'completed' && $project->download_url): ?>
                            <div class="theme-actions">
                                <a href="<?php echo esc_url($project->download_url); ?>" class="button button-primary" download>
                                    <span class="dashicons dashicons-download"></span>
                                    <?php _e('Download Theme', 'figma-wp-converter'); ?>
                                </a>
                                <button type="button" class="button button-secondary delete-project" data-project-id="<?php echo esc_attr($project->project_id); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php _e('Delete', 'figma-wp-converter'); ?>
                                </button>
                            </div>
                        <?php elseif ($project->status === 'processing'): ?>
                            <div class="theme-actions">
                                <span class="processing-message">
                                    <span class="dashicons dashicons-update spin"></span>
                                    <?php _e('Processing...', 'figma-wp-converter'); ?>
                                </span>
                            </div>
                        <?php elseif ($project->status === 'failed'): ?>
                            <div class="theme-actions">
                                <span class="error-message">
                                    <span class="dashicons dashicons-warning"></span>
                                    <?php _e('Generation failed', 'figma-wp-converter'); ?>
                                </span>
                                <a href="<?php echo admin_url('admin.php?page=figma-wp-converter'); ?>" class="button button-secondary">
                                    <?php _e('Try Again', 'figma-wp-converter'); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="themes-footer">
            <p class="themes-note">
                <strong><?php _e('Note:', 'figma-wp-converter'); ?></strong>
                <?php _e('Generated themes are automatically cleaned up after 30 days. Make sure to download and backup your themes.', 'figma-wp-converter'); ?>
            </p>
        </div>
        
    <?php endif; ?>
</div>

<style>
.figma-wp-themes {
    max-width: 1200px;
}

.no-themes-message {
    text-align: center;
    padding: 60px 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-top: 30px;
}

.no-themes-icon {
    font-size: 64px;
    margin-bottom: 20px;
}

.no-themes-content h2 {
    margin-bottom: 15px;
    color: #333;
}

.no-themes-content p {
    color: #666;
    margin-bottom: 25px;
    font-size: 16px;
}

.themes-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 6px;
}

.themes-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.theme-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    transition: box-shadow 0.3s ease;
}

.theme-card:hover {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.theme-card-header {
    background: #f8f9fa;
    padding: 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.theme-title {
    margin: 0;
    font-size: 18px;
    color: #333;
}

.theme-status {
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
}

.status-completed {
    background: #d4edda;
    color: #155724;
}

.status-processing {
    background: #fff3cd;
    color: #856404;
}

.status-failed {
    background: #f8d7da;
    color: #721c24;
}

.status-pending {
    background: #e2e3e5;
    color: #383d41;
}

.theme-card-content {
    padding: 20px;
}

.theme-meta {
    margin-bottom: 20px;
}

.meta-item {
    margin-bottom: 8px;
    font-size: 14px;
    color: #666;
}

.meta-item strong {
    color: #333;
}

.meta-item code {
    background: #f1f1f1;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 12px;
}

.theme-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.theme-actions .button {
    display: flex;
    align-items: center;
    gap: 5px;
}

.processing-message,
.error-message {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 14px;
}

.processing-message {
    color: #856404;
}

.error-message {
    color: #721c24;
}

.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.themes-footer {
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 20px;
}

.themes-note {
    margin: 0;
    color: #666;
    font-size: 14px;
}

@media (max-width: 768px) {
    .themes-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .themes-grid {
        grid-template-columns: 1fr;
    }
    
    .theme-card-header {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }
    
    .theme-actions {
        flex-direction: column;
    }
    
    .theme-actions .button {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    $('.delete-project').on('click', function() {
        if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
            return;
        }
        
        const projectId = $(this).data('project-id');
        const card = $(this).closest('.theme-card');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'delete_figma_project',
                project_id: projectId,
                nonce: '<?php echo wp_create_nonce('figma_wp_nonce'); ?>'
            },
            beforeSend: function() {
                card.css('opacity', '0.5');
            },
            success: function(response) {
                if (response.success) {
                    card.fadeOut(300, function() {
                        $(this).remove();
                        
                        // Check if no more cards
                        if ($('.theme-card').length === 0) {
                            location.reload();
                        }
                    });
                } else {
                    alert('Failed to delete project: ' + response.data.message);
                    card.css('opacity', '1');
                }
            },
            error: function() {
                alert('Failed to delete project due to server error');
                card.css('opacity', '1');
            }
        });
    });
});
</script>
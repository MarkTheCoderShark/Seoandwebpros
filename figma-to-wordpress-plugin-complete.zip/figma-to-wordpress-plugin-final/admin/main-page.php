<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap figma-wp-converter">
    <h1><?php _e('Figma to WordPress Theme Converter', 'figma-wp-converter'); ?></h1>
    
    <div class="figma-wp-header">
        <div class="figma-wp-header-content">
            <h2><?php _e('Convert your Figma designs to pixel-perfect WordPress themes', 'figma-wp-converter'); ?></h2>
            <p><?php _e('Upload screenshots of your Figma design and get a complete, responsive WordPress theme in minutes.', 'figma-wp-converter'); ?></p>
        </div>
        <div class="figma-wp-header-actions">
            <a href="<?php echo admin_url('admin.php?page=figma-wp-instructions'); ?>" class="button button-secondary">
                <span class="dashicons dashicons-info"></span>
                <?php _e('View Instructions', 'figma-wp-converter'); ?>
            </a>
        </div>
    </div>

    <div class="figma-wp-main-content">
        
        <!-- Step 1: Project Information -->
        <div class="figma-wp-card" id="step-1">
            <div class="figma-wp-card-header">
                <h3><span class="step-number">1</span><?php _e('Project Information', 'figma-wp-converter'); ?></h3>
                <p><?php _e('Tell us about your project and Figma design', 'figma-wp-converter'); ?></p>
            </div>
            
            <div class="figma-wp-card-content">
                <form id="figma-conversion-form">
                    <?php wp_nonce_field('figma_wp_nonce', 'figma_wp_nonce'); ?>
                    
                    <div class="form-group">
                        <label for="project_name"><?php _e('Project Name', 'figma-wp-converter'); ?> <span class="required">*</span></label>
                        <input type="text" id="project_name" name="project_name" required 
                               placeholder="<?php _e('e.g., My Wellness Website', 'figma-wp-converter'); ?>" />
                        <p class="description"><?php _e('Give your project a descriptive name for easy identification.', 'figma-wp-converter'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="figma_url"><?php _e('Figma Design URL', 'figma-wp-converter'); ?> <span class="required">*</span></label>
                        <input type="url" id="figma_url" name="figma_url" required 
                               placeholder="https://www.figma.com/design/..." />
                        <p class="description">
                            <?php _e('Paste your Figma design URL here. Make sure it\'s publicly accessible or shared with view permissions.', 'figma-wp-converter'); ?>
                            <br><strong><?php _e('Example:', 'figma-wp-converter'); ?></strong> https://www.figma.com/design/KOQa1duALOfvPb7ltYZ0tk/Your-Design-Name
                        </p>
                        <div id="figma-url-validation" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="business_type"><?php _e('Business Type', 'figma-wp-converter'); ?></label>
                        <select id="business_type" name="business_type">
                            <option value=""><?php _e('Select business type', 'figma-wp-converter'); ?></option>
                            <option value="wellness"><?php _e('Wellness & Spa', 'figma-wp-converter'); ?></option>
                            <option value="restaurant"><?php _e('Restaurant & Food', 'figma-wp-converter'); ?></option>
                            <option value="business"><?php _e('Business & Corporate', 'figma-wp-converter'); ?></option>
                            <option value="portfolio"><?php _e('Portfolio & Creative', 'figma-wp-converter'); ?></option>
                            <option value="ecommerce"><?php _e('E-commerce & Shop', 'figma-wp-converter'); ?></option>
                            <option value="blog"><?php _e('Blog & Magazine', 'figma-wp-converter'); ?></option>
                            <option value="other"><?php _e('Other', 'figma-wp-converter'); ?></option>
                        </select>
                        <p class="description"><?php _e('This helps us optimize the theme structure for your industry.', 'figma-wp-converter'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="color_scheme"><?php _e('Primary Color Scheme', 'figma-wp-converter'); ?></label>
                        <select id="color_scheme" name="color_scheme">
                            <option value="auto"><?php _e('Auto-detect from screenshots', 'figma-wp-converter'); ?></option>
                            <option value="light"><?php _e('Light Theme', 'figma-wp-converter'); ?></option>
                            <option value="dark"><?php _e('Dark Theme', 'figma-wp-converter'); ?></option>
                            <option value="colorful"><?php _e('Colorful Theme', 'figma-wp-converter'); ?></option>
                        </select>
                    </div>
                    
                </form>
            </div>
        </div>

        <!-- Step 2: Screenshot Upload -->
        <div class="figma-wp-card" id="step-2">
            <div class="figma-wp-card-header">
                <h3><span class="step-number">2</span><?php _e('Upload Design Screenshots', 'figma-wp-converter'); ?></h3>
                <p><?php _e('Upload screenshots of your Figma design sections in the correct order', 'figma-wp-converter'); ?></p>
            </div>
            
            <div class="figma-wp-card-content">
                
                <!-- Screenshot Naming Guide -->
                <div class="screenshot-guide">
                    <h4><?php _e('📷 Screenshot Naming Guide', 'figma-wp-converter'); ?></h4>
                    <p><strong><?php _e('IMPORTANT: Name your screenshots in order (1-10) to match your design sections:', 'figma-wp-converter'); ?></strong></p>
                    
                    <div class="naming-examples">
                        <div class="naming-example">
                            <span class="file-name">1-hero.png</span>
                            <span class="file-desc"><?php _e('Hero/Header section with navigation', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">2-services.png</span>
                            <span class="file-desc"><?php _e('Services or features section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">3-about.png</span>
                            <span class="file-desc"><?php _e('About or description section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">4-pricing.png</span>
                            <span class="file-desc"><?php _e('Pricing or membership section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">5-testimonials.png</span>
                            <span class="file-desc"><?php _e('Testimonials or reviews section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">6-blog.png</span>
                            <span class="file-desc"><?php _e('Blog or news section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">7-cta.png</span>
                            <span class="file-desc"><?php _e('Call-to-action section', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="naming-example">
                            <span class="file-name">8-footer.png</span>
                            <span class="file-desc"><?php _e('Footer section', 'figma-wp-converter'); ?></span>
                        </div>
                    </div>
                    
                    <div class="screenshot-requirements">
                        <h5><?php _e('📋 Requirements:', 'figma-wp-converter'); ?></h5>
                        <ul>
                            <li><?php _e('✅ Use PNG or JPG format', 'figma-wp-converter'); ?></li>
                            <li><?php _e('✅ Name files in order: 1-section.png, 2-section.png, etc.', 'figma-wp-converter'); ?></li>
                            <li><?php _e('✅ Full-width screenshots (at least 1200px wide)', 'figma-wp-converter'); ?></li>
                            <li><?php _e('✅ Maximum file size: 10MB per image', 'figma-wp-converter'); ?></li>
                            <li><?php _e('✅ Include all text and visual elements clearly', 'figma-wp-converter'); ?></li>
                            <li><?php _e('⚠️ Avoid overlapping content between screenshots', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Screenshot Upload Area -->
                <div class="screenshot-upload-area">
                    <div class="upload-dropzone" id="screenshot-dropzone">
                        <div class="dropzone-content">
                            <div class="dropzone-icon">📷</div>
                            <h4><?php _e('Drop screenshots here or click to upload', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('Select multiple files at once (up to 10 screenshots)', 'figma-wp-converter'); ?></p>
                            <button type="button" class="button button-primary" id="select-screenshots">
                                <?php _e('Select Screenshots', 'figma-wp-converter'); ?>
                            </button>
                        </div>
                        <input type="file" id="screenshot-files" multiple accept=".png,.jpg,.jpeg" style="display: none;" />
                    </div>
                    
                    <!-- Upload Progress -->
                    <div class="upload-progress" id="upload-progress" style="display: none;">
                        <div class="progress-bar">
                            <div class="progress-fill"></div>
                        </div>
                        <p class="progress-text"><?php _e('Uploading screenshots...', 'figma-wp-converter'); ?></p>
                    </div>
                    
                    <!-- Uploaded Screenshots Preview -->
                    <div class="uploaded-screenshots" id="uploaded-screenshots"></div>
                </div>
                
            </div>
        </div>

        <!-- Step 3: Section Configuration -->
        <div class="figma-wp-card" id="step-3">
            <div class="figma-wp-card-header">
                <h3><span class="step-number">3</span><?php _e('Configure Theme Sections', 'figma-wp-converter'); ?></h3>
                <p><?php _e('Tell us what type of sections you have so we can generate the most accurate theme', 'figma-wp-converter'); ?></p>
            </div>
            
            <div class="figma-wp-card-content">
                <div class="sections-config">
                    <p><?php _e('Select the sections that match your uploaded screenshots:', 'figma-wp-converter'); ?></p>
                    
                    <div class="sections-grid">
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="hero" checked>
                            <span class="section-info">
                                <strong><?php _e('Hero/Header', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Main banner with navigation and call-to-action', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="services">
                            <span class="section-info">
                                <strong><?php _e('Services/Features', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Grid of services, features, or products', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="about">
                            <span class="section-info">
                                <strong><?php _e('About/Story', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Company story, mission, or description', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="pricing">
                            <span class="section-info">
                                <strong><?php _e('Pricing/Plans', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Pricing tables, membership plans, or packages', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="testimonials">
                            <span class="section-info">
                                <strong><?php _e('Testimonials/Reviews', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Customer reviews and testimonials', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="team">
                            <span class="section-info">
                                <strong><?php _e('Team/Staff', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Team member profiles and bios', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="blog">
                            <span class="section-info">
                                <strong><?php _e('Blog/News', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Latest articles, news, or insights', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="gallery">
                            <span class="section-info">
                                <strong><?php _e('Gallery/Portfolio', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Image gallery or portfolio showcase', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="contact">
                            <span class="section-info">
                                <strong><?php _e('Contact/Location', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Contact form, address, or location info', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                        
                        <label class="section-checkbox">
                            <input type="checkbox" name="sections[]" value="footer" checked>
                            <span class="section-info">
                                <strong><?php _e('Footer', 'figma-wp-converter'); ?></strong>
                                <small><?php _e('Site footer with links and information', 'figma-wp-converter'); ?></small>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 4: Generate Theme -->
        <div class="figma-wp-card" id="step-4">
            <div class="figma-wp-card-header">
                <h3><span class="step-number">4</span><?php _e('Generate WordPress Theme', 'figma-wp-converter'); ?></h3>
                <p><?php _e('Review your settings and generate your pixel-perfect WordPress theme', 'figma-wp-converter'); ?></p>
            </div>
            
            <div class="figma-wp-card-content">
                <div class="generation-summary" id="generation-summary">
                    <h4><?php _e('Generation Summary', 'figma-wp-converter'); ?></h4>
                    <div class="summary-content">
                        <p class="summary-item"><strong><?php _e('Project:', 'figma-wp-converter'); ?></strong> <span id="summary-project-name">-</span></p>
                        <p class="summary-item"><strong><?php _e('Business Type:', 'figma-wp-converter'); ?></strong> <span id="summary-business-type">-</span></p>
                        <p class="summary-item"><strong><?php _e('Screenshots:', 'figma-wp-converter'); ?></strong> <span id="summary-screenshots">0 uploaded</span></p>
                        <p class="summary-item"><strong><?php _e('Sections:', 'figma-wp-converter'); ?></strong> <span id="summary-sections">-</span></p>
                    </div>
                </div>
                
                <div class="generation-actions">
                    <button type="button" class="button button-primary button-large" id="generate-theme" disabled>
                        <span class="button-text"><?php _e('Generate WordPress Theme', 'figma-wp-converter'); ?></span>
                        <span class="button-spinner" style="display: none;">
                            <span class="spinner is-active"></span>
                            <?php _e('Generating...', 'figma-wp-converter'); ?>
                        </span>
                    </button>
                </div>
                
                <div class="generation-progress" id="generation-progress" style="display: none;">
                    <div class="progress-steps">
                        <div class="progress-step" data-step="analyzing">
                            <div class="step-indicator"></div>
                            <span><?php _e('Analyzing screenshots...', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="progress-step" data-step="extracting">
                            <div class="step-indicator"></div>
                            <span><?php _e('Extracting design elements...', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="progress-step" data-step="generating">
                            <div class="step-indicator"></div>
                            <span><?php _e('Generating theme files...', 'figma-wp-converter'); ?></span>
                        </div>
                        <div class="progress-step" data-step="packaging">
                            <div class="step-indicator"></div>
                            <span><?php _e('Packaging theme...', 'figma-wp-converter'); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="generation-result" id="generation-result" style="display: none;">
                    <!-- Results will be populated by JavaScript -->
                </div>
            </div>
        </div>

    </div>
    
    <!-- Quick Tips Sidebar -->
    <div class="figma-wp-sidebar">
        <div class="sidebar-card tips-card">
            <h3><?php _e('💡 Quick Tips', 'figma-wp-converter'); ?></h3>
            <ul class="tips-list">
                <li><?php _e('Take full-width screenshots at desktop size (1200px+ wide)', 'figma-wp-converter'); ?></li>
                <li><?php _e('Name your files in order: 1-hero.png, 2-services.png, etc.', 'figma-wp-converter'); ?></li>
                <li><?php _e('Include all text content clearly visible in screenshots', 'figma-wp-converter'); ?></li>
                <li><?php _e('Make sure your Figma URL is publicly accessible', 'figma-wp-converter'); ?></li>
                <li><?php _e('Avoid overlapping content between different sections', 'figma-wp-converter'); ?></li>
            </ul>
        </div>
        
        <div class="sidebar-card help-card">
            <h3><?php _e('🆘 Need Help?', 'figma-wp-converter'); ?></h3>
            <p><?php _e('Check out our detailed instructions for step-by-step guidance.', 'figma-wp-converter'); ?></p>
            <a href="<?php echo admin_url('admin.php?page=figma-wp-instructions'); ?>" class="button button-secondary">
                <?php _e('View Instructions', 'figma-wp-converter'); ?>
            </a>
        </div>
    </div>
    
</div>

<style>
.figma-wp-converter {
    max-width: 1200px;
    margin: 0;
}

.figma-wp-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    border-left: 4px solid #0073aa;
}

.figma-wp-main-content {
    float: left;
    width: 70%;
    padding-right: 30px;
}

.figma-wp-sidebar {
    float: right;
    width: 25%;
}

.figma-wp-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 25px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.figma-wp-card-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
    background: #fafafa;
}

.figma-wp-card-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.step-number {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    background: #0073aa;
    color: white;
    border-radius: 50%;
    font-size: 14px;
    font-weight: bold;
}

.figma-wp-card-content {
    padding: 25px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 5px;
}

.required {
    color: #d63638;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.description {
    margin-top: 5px;
    color: #666;
    font-size: 13px;
}

.screenshot-guide {
    background: #e7f3ff;
    border: 1px solid #b3d9ff;
    border-radius: 6px;
    padding: 20px;
    margin-bottom: 25px;
}

.naming-examples {
    margin: 15px 0;
}

.naming-example {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(179, 217, 255, 0.3);
}

.file-name {
    font-family: monospace;
    background: #fff;
    padding: 4px 8px;
    border-radius: 3px;
    font-weight: bold;
    min-width: 120px;
}

.file-desc {
    color: #444;
}

.screenshot-requirements {
    margin-top: 15px;
}

.screenshot-requirements ul {
    margin: 10px 0;
    padding-left: 20px;
}

.screenshot-requirements li {
    margin-bottom: 5px;
}

.upload-dropzone {
    border: 2px dashed #ddd;
    border-radius: 8px;
    padding: 40px 20px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
}

.upload-dropzone:hover,
.upload-dropzone.dragover {
    border-color: #0073aa;
    background: #f0f8ff;
}

.dropzone-icon {
    font-size: 48px;
    margin-bottom: 15px;
}

.sections-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.section-checkbox {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.section-checkbox:hover {
    background: #f9f9f9;
}

.section-checkbox input[type="checkbox"] {
    margin: 0;
    width: auto;
}

.section-info {
    flex: 1;
}

.section-info strong {
    display: block;
    margin-bottom: 3px;
}

.section-info small {
    color: #666;
    font-size: 12px;
}

.generation-summary {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 20px;
    margin-bottom: 20px;
}

.summary-item {
    margin-bottom: 8px;
}

.generation-actions {
    text-align: center;
    margin: 30px 0;
}

.button-large {
    padding: 12px 30px;
    font-size: 16px;
}

.sidebar-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
}

.sidebar-card h3 {
    margin-top: 0;
    margin-bottom: 15px;
}

.tips-list {
    list-style: none;
    padding: 0;
}

.tips-list li {
    padding: 8px 0;
    border-bottom: 1px solid #eee;
}

.tips-list li:last-child {
    border-bottom: none;
}

.clearfix::after {
    content: "";
    display: table;
    clear: both;
}

@media (max-width: 768px) {
    .figma-wp-main-content,
    .figma-wp-sidebar {
        float: none;
        width: 100%;
        padding-right: 0;
    }
    
    .figma-wp-header {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }
    
    .sections-grid {
        grid-template-columns: 1fr;
    }
}
</style>
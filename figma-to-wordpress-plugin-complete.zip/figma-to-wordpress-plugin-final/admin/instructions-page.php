<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap figma-wp-instructions">
    <h1><?php _e('📖 Figma to WordPress - Complete Instructions', 'figma-wp-converter'); ?></h1>
    
    <div class="instructions-nav">
        <ul class="nav-tabs">
            <li class="nav-tab active" data-tab="overview"><?php _e('Overview', 'figma-wp-converter'); ?></li>
            <li class="nav-tab" data-tab="screenshots"><?php _e('Screenshots Guide', 'figma-wp-converter'); ?></li>
            <li class="nav-tab" data-tab="figma-setup"><?php _e('Figma Setup', 'figma-wp-converter'); ?></li>
            <li class="nav-tab" data-tab="theme-customization"><?php _e('Theme Customization', 'figma-wp-converter'); ?></li>
            <li class="nav-tab" data-tab="troubleshooting"><?php _e('Troubleshooting', 'figma-wp-converter'); ?></li>
        </ul>
    </div>

    <div class="instructions-content">
        
        <!-- Overview Tab -->
        <div class="tab-content active" id="overview">
            <h2><?php _e('🚀 Getting Started', 'figma-wp-converter'); ?></h2>
            
            <div class="overview-grid">
                <div class="overview-card">
                    <div class="card-icon">🎨</div>
                    <h3><?php _e('1. Prepare Your Figma Design', 'figma-wp-converter'); ?></h3>
                    <p><?php _e('Make sure your Figma design is complete and publicly accessible. Organize your design into clear sections like Header, Services, About, etc.', 'figma-wp-converter'); ?></p>
                </div>
                
                <div class="overview-card">
                    <div class="card-icon">📷</div>
                    <h3><?php _e('2. Take Screenshots', 'figma-wp-converter'); ?></h3>
                    <p><?php _e('Capture full-width screenshots of each section in order. Name them nav.png, hero.png, 1.png, 2.png, etc., footer.png. Include all text and visual elements.', 'figma-wp-converter'); ?></p>
                </div>
                
                <div class="overview-card">
                    <div class="card-icon">⚙️</div>
                    <h3><?php _e('3. Configure & Generate', 'figma-wp-converter'); ?></h3>
                    <p><?php _e('Upload your screenshots, configure section types, and let our AI analyze your design to generate a pixel-perfect WordPress theme.', 'figma-wp-converter'); ?></p>
                </div>
                
                <div class="overview-card">
                    <div class="card-icon">🎉</div>
                    <h3><?php _e('4. Install & Customize', 'figma-wp-converter'); ?></h3>
                    <p><?php _e('Download your generated theme, install it on WordPress, add your content and images, then customize using the WordPress Customizer.', 'figma-wp-converter'); ?></p>
                </div>
            </div>
            
            <div class="process-timeline">
                <h3><?php _e('Complete Process Timeline', 'figma-wp-converter'); ?></h3>
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-marker">1</div>
                        <div class="timeline-content">
                            <h4><?php _e('Design Preparation (5-10 minutes)', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('Finalize your Figma design and make it publicly accessible', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-marker">2</div>
                        <div class="timeline-content">
                            <h4><?php _e('Screenshot Creation (10-15 minutes)', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('Take ordered screenshots of each section and name them properly', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-marker">3</div>
                        <div class="timeline-content">
                            <h4><?php _e('Plugin Configuration (5 minutes)', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('Fill out project details and upload screenshots', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-marker">4</div>
                        <div class="timeline-content">
                            <h4><?php _e('Theme Generation (2-5 minutes)', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('AI analyzes your design and generates WordPress theme files', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-marker">5</div>
                        <div class="timeline-content">
                            <h4><?php _e('Installation & Setup (10-20 minutes)', 'figma-wp-converter'); ?></h4>
                            <p><?php _e('Install theme, add content, images, and final customizations', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Screenshots Guide Tab -->
        <div class="tab-content" id="screenshots">
            <h2><?php _e('📷 Complete Screenshots Guide', 'figma-wp-converter'); ?></h2>
            
            <div class="screenshot-requirements-detailed">
                <h3><?php _e('📋 Technical Requirements', 'figma-wp-converter'); ?></h3>
                <div class="requirements-grid">
                    <div class="requirement-item">
                        <span class="req-icon">📐</span>
                        <div>
                            <strong><?php _e('Dimensions:', 'figma-wp-converter'); ?></strong>
                            <p><?php _e('Minimum 1200px wide, any height. Desktop viewport preferred.', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="requirement-item">
                        <span class="req-icon">🖼️</span>
                        <div>
                            <strong><?php _e('Format:', 'figma-wp-converter'); ?></strong>
                            <p><?php _e('PNG (preferred) or JPG. Avoid GIF or WebP.', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="requirement-item">
                        <span class="req-icon">📏</span>
                        <div>
                            <strong><?php _e('File Size:', 'figma-wp-converter'); ?></strong>
                            <p><?php _e('Maximum 10MB per file. Compress if necessary.', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                    <div class="requirement-item">
                        <span class="req-icon">🎯</span>
                        <div>
                            <strong><?php _e('Quality:', 'figma-wp-converter'); ?></strong>
                            <p><?php _e('High resolution, all text readable, colors accurate.', 'figma-wp-converter'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="naming-guide-detailed">
                <h3><?php _e('📝 Screenshot Naming Guide', 'figma-wp-converter'); ?></h3>
                <p><strong><?php _e('CRITICAL: Name your files in the exact order they appear on your website, starting with 1:', 'figma-wp-converter'); ?></strong></p>
                
                <div class="naming-table">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('File Name', 'figma-wp-converter'); ?></th>
                                <th><?php _e('Section Description', 'figma-wp-converter'); ?></th>
                                <th><?php _e('What to Include', 'figma-wp-converter'); ?></th>
                                <th><?php _e('Example', 'figma-wp-converter'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><code>nav.png</code></td>
                                <td><?php _e('Navigation/Header', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Navigation menu, logo, header area', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Top navigation with logo and menu items', 'figma-wp-converter'); ?></td>
                            </tr>
                            <tr>
                                <td><code>hero.png</code></td>
                                <td><?php _e('Hero Section', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Main headline, hero image/video, primary CTA buttons', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Hero banner with "Welcome to Our Spa" and "Book Now" button', 'figma-wp-converter'); ?></td>
                            </tr>
                            <tr>
                                <td><code>1.png</code></td>
                                <td><?php _e('First Content Section', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Services, features, or main content area', 'figma-wp-converter'); ?></td>
                                <td><?php _e('3-column grid showing "Massage", "Facials", "Wellness"', 'figma-wp-converter'); ?></td>
                            </tr>
                            <tr>
                                <td><code>2.png</code></td>
                                <td><?php _e('Second Content Section', 'figma-wp-converter'); ?></td>
                                <td><?php _e('About, story, additional content', 'figma-wp-converter'); ?></td>
                                <td><?php _e('About section with team photos and company story', 'figma-wp-converter'); ?></td>
                            </tr>
                            <tr>
                                <td><code>...</code></td>
                                <td><?php _e('Additional Sections', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Continue numbering: 3.png, 4.png, 5.png, 6.png, 7.png', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Features, testimonials, pricing, contact, gallery', 'figma-wp-converter'); ?></td>
                            </tr>
                            <tr>
                                <td><code>footer.png</code></td>
                                <td><?php _e('Footer Section', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Footer links, copyright, contact info, social media', 'figma-wp-converter'); ?></td>
                                <td><?php _e('Footer with links, address, and social icons', 'figma-wp-converter'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="screenshot-tips">
                <h3><?php _e('💡 Pro Tips for Better Results', 'figma-wp-converter'); ?></h3>
                <div class="tips-grid">
                    <div class="tip-item success">
                        <span class="tip-icon">✅</span>
                        <div>
                            <strong><?php _e('DO:', 'figma-wp-converter'); ?></strong>
                            <ul>
                                <li><?php _e('Capture full section width (edge to edge)', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Include all text content clearly readable', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Show buttons, links, and interactive elements', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Maintain consistent naming: 1-, 2-, 3-, etc.', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Use descriptive section names after numbers', 'figma-wp-converter'); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="tip-item warning">
                        <span class="tip-icon">❌</span>
                        <div>
                            <strong><?php _e('DON\'T:', 'figma-wp-converter'); ?></strong>
                            <ul>
                                <li><?php _e('Crop sections or cut off content', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Include multiple sections in one screenshot', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Use blurry or low-resolution images', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Name files randomly (hero, about, etc.)', 'figma-wp-converter'); ?></li>
                                <li><?php _e('Skip sections or change the order', 'figma-wp-converter'); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Figma Setup Tab -->
        <div class="tab-content" id="figma-setup">
            <h2><?php _e('🎨 Figma Setup Guide', 'figma-wp-converter'); ?></h2>
            
            <div class="figma-steps">
                <div class="figma-step">
                    <div class="step-header">
                        <span class="step-number">1</span>
                        <h3><?php _e('Make Your Figma File Public', 'figma-wp-converter'); ?></h3>
                    </div>
                    <div class="step-content">
                        <ol>
                            <li><?php _e('Open your Figma design file', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Click the "Share" button in the top-right corner', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Select "Anyone with the link" and set to "can view"', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Copy the share link - this is what you\'ll paste in our plugin', 'figma-wp-converter'); ?></li>
                        </ol>
                        <div class="figma-url-example">
                            <strong><?php _e('Example URL:', 'figma-wp-converter'); ?></strong>
                            <code>https://www.figma.com/design/KOQa1duALOfvPb7ltYZ0tk/Your-Design-Name?node-id=1-2&m=dev</code>
                        </div>
                    </div>
                </div>
                
                <div class="figma-step">
                    <div class="step-header">
                        <span class="step-number">2</span>
                        <h3><?php _e('Organize Your Design', 'figma-wp-converter'); ?></h3>
                    </div>
                    <div class="step-content">
                        <p><?php _e('For best results, organize your Figma design with:', 'figma-wp-converter'); ?></p>
                        <ul>
                            <li><?php _e('Clear section separation (use frames or pages)', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Consistent spacing between sections', 'figma-wp-converter'); ?></li>
                            <li><?php _e('All text layers properly named and styled', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Color styles defined for consistency', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Components used for repeated elements', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                </div>
                
                <div class="figma-step">
                    <div class="step-header">
                        <span class="step-number">3</span>
                        <h3><?php _e('Prepare Assets', 'figma-wp-converter'); ?></h3>
                    </div>
                    <div class="step-content">
                        <p><?php _e('Before generating your theme, prepare these assets:', 'figma-wp-converter'); ?></p>
                        <div class="assets-checklist">
                            <label><input type="checkbox"> <?php _e('Logo files (PNG/SVG format)', 'figma-wp-converter'); ?></label>
                            <label><input type="checkbox"> <?php _e('High-quality images (1920x1080 or larger)', 'figma-wp-converter'); ?></label>
                            <label><input type="checkbox"> <?php _e('Team member photos', 'figma-wp-converter'); ?></label>
                            <label><input type="checkbox"> <?php _e('Product/service images', 'figma-wp-converter'); ?></label>
                            <label><input type="checkbox"> <?php _e('Final website copy/content', 'figma-wp-converter'); ?></label>
                            <label><input type="checkbox"> <?php _e('Contact information and details', 'figma-wp-converter'); ?></label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="figma-troubleshooting">
                <h3><?php _e('🔧 Common Figma Issues', 'figma-wp-converter'); ?></h3>
                <div class="troubleshooting-grid">
                    <div class="trouble-item">
                        <h4><?php _e('❌ "Can\'t access Figma file"', 'figma-wp-converter'); ?></h4>
                        <p><strong><?php _e('Solution:', 'figma-wp-converter'); ?></strong> <?php _e('Make sure sharing is set to "Anyone with the link can view" and the URL is complete.', 'figma-wp-converter'); ?></p>
                    </div>
                    <div class="trouble-item">
                        <h4><?php _e('❌ "Design looks different"', 'figma-wp-converter'); ?></h4>
                        <p><strong><?php _e('Solution:', 'figma-wp-converter'); ?></strong> <?php _e('Take fresh screenshots at 100% zoom level in Figma to ensure accuracy.', 'figma-wp-converter'); ?></p>
                    </div>
                    <div class="trouble-item">
                        <h4><?php _e('❌ "Missing fonts"', 'figma-wp-converter'); ?></h4>
                        <p><strong><?php _e('Solution:', 'figma-wp-converter'); ?></strong> <?php _e('We use web-safe fonts. Your design will use the closest Google Fonts equivalent.', 'figma-wp-converter'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Theme Customization Tab -->
        <div class="tab-content" id="theme-customization">
            <h2><?php _e('🎨 Theme Customization Guide', 'figma-wp-converter'); ?></h2>
            
            <div class="customization-workflow">
                <h3><?php _e('Post-Generation Workflow', 'figma-wp-converter'); ?></h3>
                <div class="workflow-steps">
                    <div class="workflow-step">
                        <div class="step-icon">📥</div>
                        <h4><?php _e('1. Download & Install', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Download your generated theme ZIP file', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Go to WordPress Admin > Appearance > Themes', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Click "Add New" > "Upload Theme"', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Upload and activate your theme', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="workflow-step">
                        <div class="step-icon">🖼️</div>
                        <h4><?php _e('2. Add Your Images', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Upload your logo in Appearance > Customize > Site Identity', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Replace placeholder images with your actual photos', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Add hero background images', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Update service/feature images', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="workflow-step">
                        <div class="step-icon">📝</div>
                        <h4><?php _e('3. Update Content', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Replace placeholder text with your actual copy', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Update contact information', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Add your business details', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Configure menus and navigation', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="workflow-step">
                        <div class="step-icon">⚙️</div>
                        <h4><?php _e('4. Final Customization', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Fine-tune colors using WordPress Customizer', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Adjust typography if needed', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Set up contact forms', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Configure SEO settings', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="customization-options">
                <h3><?php _e('Available Customization Options', 'figma-wp-converter'); ?></h3>
                <div class="options-grid">
                    <div class="option-card">
                        <h4><?php _e('🎨 Colors & Branding', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Primary brand colors', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Accent colors', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Background colors', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Logo upload and placement', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="option-card">
                        <h4><?php _e('📝 Content & Layout', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Hero section content', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Service descriptions', 'figma-wp-converter'); ?></li>
                            <li><?php _e('About section text', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Contact information', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="option-card">
                        <h4><?php _e('🖼️ Images & Media', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Background images', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Service/feature images', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Team member photos', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Gallery images', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="option-card">
                        <h4><?php _e('⚙️ Functionality', 'figma-wp-converter'); ?></h4>
                        <ul>
                            <li><?php _e('Contact forms', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Social media links', 'figma-wp-converter'); ?></li>
                            <li><?php _e('Newsletter signup', 'figma-wp-converter'); ?></li>
                            <li><?php _e('SEO optimization', 'figma-wp-converter'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Troubleshooting Tab -->
        <div class="tab-content" id="troubleshooting">
            <h2><?php _e('🔧 Troubleshooting Guide', 'figma-wp-converter'); ?></h2>
            
            <div class="troubleshooting-section">
                <h3><?php _e('Common Issues & Solutions', 'figma-wp-converter'); ?></h3>
                
                <div class="trouble-categories">
                    <div class="trouble-category">
                        <h4><?php _e('📤 Upload Issues', 'figma-wp-converter'); ?></h4>
                        <div class="trouble-items">
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Screenshots won\'t upload', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Check file size (max 10MB), format (PNG/JPG only), and internet connection. Try uploading one at a time.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                            
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: "Invalid file type" error', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Only PNG and JPG files are accepted. Convert GIF, WebP, or other formats to PNG.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="trouble-category">
                        <h4><?php _e('🎨 Design Issues', 'figma-wp-converter'); ?></h4>
                        <div class="trouble-items">
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Colors don\'t match my design', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Take high-quality screenshots with accurate colors. You can adjust colors in WordPress Customizer after installation.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                            
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Layout looks different than expected', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Ensure screenshots are full-width and properly ordered (1-, 2-, 3-, etc.). Each section should be in a separate screenshot.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                            
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Text is hard to read', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Take screenshots at 100% zoom in Figma. Ensure all text is clearly visible and readable in your screenshots.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="trouble-category">
                        <h4><?php _e('⚙️ Generation Issues', 'figma-wp-converter'); ?></h4>
                        <div class="trouble-items">
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Theme generation fails', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Check that all required fields are filled, screenshots are properly named and uploaded, and your internet connection is stable.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                            
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Generated theme is missing sections', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Verify that you uploaded screenshots for all sections and selected the correct section types in step 3.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="trouble-category">
                        <h4><?php _e('📱 Mobile/Responsive Issues', 'figma-wp-converter'); ?></h4>
                        <div class="trouble-items">
                            <div class="trouble-qa">
                                <div class="trouble-question">
                                    <strong><?php _e('Q: Theme doesn\'t look good on mobile', 'figma-wp-converter'); ?></strong>
                                </div>
                                <div class="trouble-answer">
                                    <strong><?php _e('A:', 'figma-wp-converter'); ?></strong> <?php _e('Our themes are mobile-responsive by default. Test on actual devices and adjust content/images as needed.', 'figma-wp-converter'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="contact-support">
                <h3><?php _e('📞 Still Need Help?', 'figma-wp-converter'); ?></h3>
                <p><?php _e('If you\'re still having issues after trying these solutions:', 'figma-wp-converter'); ?></p>
                <ul>
                    <li><?php _e('Double-check you\'ve followed all instructions exactly', 'figma-wp-converter'); ?></li>
                    <li><?php _e('Try with a simplified design first to test the process', 'figma-wp-converter'); ?></li>
                    <li><?php _e('Contact our support team with specific error messages', 'figma-wp-converter'); ?></li>
                    <li><?php _e('Include your project details and screenshots when asking for help', 'figma-wp-converter'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
.figma-wp-instructions {
    max-width: 1200px;
}

.instructions-nav {
    margin-bottom: 30px;
}

.nav-tabs {
    list-style: none;
    display: flex;
    border-bottom: 2px solid #ddd;
    margin: 0;
    padding: 0;
}

.nav-tab {
    padding: 12px 20px;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    transition: all 0.3s ease;
}

.nav-tab:hover,
.nav-tab.active {
    background: #f9f9f9;
    border-bottom-color: #0073aa;
}

.tab-content {
    display: none;
    padding: 30px 0;
}

.tab-content.active {
    display: block;
}

.overview-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin: 30px 0;
}

.overview-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 25px;
    text-align: center;
}

.card-icon {
    font-size: 48px;
    margin-bottom: 15px;
}

.timeline {
    margin: 30px 0;
}

.timeline-item {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 30px;
    padding-bottom: 30px;
    border-bottom: 1px solid #eee;
}

.timeline-marker {
    background: #0073aa;
    color: white;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    flex-shrink: 0;
}

.timeline-content h4 {
    margin-bottom: 8px;
    color: #0073aa;
}

.requirements-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.requirement-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 6px;
}

.req-icon {
    font-size: 24px;
}

.naming-table {
    margin: 20px 0;
    overflow-x: auto;
}

.naming-table code {
    background: #f1f1f1;
    padding: 4px 8px;
    border-radius: 3px;
    font-weight: bold;
}

.tips-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
    margin: 25px 0;
}

.tip-item {
    padding: 20px;
    border-radius: 8px;
    border-left: 4px solid;
}

.tip-item.success {
    background: #d4edda;
    border-left-color: #28a745;
}

.tip-item.warning {
    background: #fff3cd;
    border-left-color: #ffc107;
}

.tip-icon {
    font-size: 20px;
    margin-right: 10px;
}

.figma-steps {
    margin: 30px 0;
}

.figma-step {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 25px;
    overflow: hidden;
}

.step-header {
    background: #f8f9fa;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.step-number {
    background: #0073aa;
    color: white;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.step-content {
    padding: 25px;
}

.figma-url-example {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 6px;
    margin-top: 15px;
}

.figma-url-example code {
    display: block;
    margin-top: 10px;
    background: #e9ecef;
    padding: 10px;
    border-radius: 4px;
    word-break: break-all;
}

.assets-checklist {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 10px;
    margin: 15px 0;
}

.assets-checklist label {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
}

.troubleshooting-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.trouble-item {
    background: #fff3cd;
    border: 1px solid #ffc107;
    border-radius: 6px;
    padding: 15px;
}

.trouble-item h4 {
    margin-bottom: 10px;
    color: #856404;
}

.workflow-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin: 30px 0;
}

.workflow-step {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 25px;
    text-align: center;
}

.step-icon {
    font-size: 48px;
    margin-bottom: 15px;
}

.options-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 25px 0;
}

.option-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
}

.trouble-categories {
    margin: 30px 0;
}

.trouble-category {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 25px;
    overflow: hidden;
}

.trouble-category h4 {
    background: #f8f9fa;
    padding: 15px 20px;
    margin: 0;
    border-bottom: 1px solid #ddd;
}

.trouble-items {
    padding: 20px;
}

.trouble-qa {
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #eee;
}

.trouble-qa:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.trouble-question {
    margin-bottom: 8px;
}

.trouble-answer {
    color: #666;
}

.contact-support {
    background: #e7f3ff;
    border: 1px solid #b3d9ff;
    border-radius: 8px;
    padding: 25px;
    margin-top: 30px;
}

@media (max-width: 768px) {
    .nav-tabs {
        flex-wrap: wrap;
    }
    
    .nav-tab {
        flex: 1;
        text-align: center;
        min-width: 120px;
    }
    
    .tips-grid {
        grid-template-columns: 1fr;
    }
    
    .overview-grid,
    .requirements-grid,
    .workflow-steps,
    .options-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Tab switching
    $('.nav-tab').click(function() {
        var tab = $(this).data('tab');
        
        $('.nav-tab').removeClass('active');
        $(this).addClass('active');
        
        $('.tab-content').removeClass('active');
        $('#' + tab).addClass('active');
    });
    
    // Checklist functionality
    $('.assets-checklist input[type="checkbox"]').change(function() {
        var label = $(this).closest('label');
        if ($(this).is(':checked')) {
            label.css('opacity', '0.6');
        } else {
            label.css('opacity', '1');
        }
    });
});
</script>
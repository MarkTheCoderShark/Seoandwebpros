<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get current settings
$api_provider = get_option('fwc_api_provider', 'openai');
$api_key = get_option('fwc_api_key', '');
$api_key_decrypted = !empty($api_key) ? base64_decode($api_key) : '';
$api_key_masked = !empty($api_key_decrypted) ? substr($api_key_decrypted, 0, 7) . str_repeat('*', strlen($api_key_decrypted) - 11) . substr($api_key_decrypted, -4) : '';

$figma_token = get_option('fwc_figma_token', '');
$figma_token_decrypted = !empty($figma_token) ? base64_decode($figma_token) : '';
$figma_token_masked = !empty($figma_token_decrypted) ? substr($figma_token_decrypted, 0, 7) . str_repeat('*', strlen($figma_token_decrypted) - 11) . substr($figma_token_decrypted, -4) : '';

$openrouter_model = get_option('fwc_openrouter_model', '');
?>

<div class="wrap figma-wp-settings">
    <h1><?php _e('Figma to WordPress Settings', 'figma-wp-converter'); ?></h1>
    
    <div class="settings-container">
        <div class="settings-section">
            <h2><?php _e('AI Model Configuration', 'figma-wp-converter'); ?></h2>
            <p class="description">
                <?php _e('Configure your AI model API key to enable intelligent design analysis and accurate theme generation.', 'figma-wp-converter'); ?>
            </p>
            
            <form id="api-settings-form" method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="api_provider"><?php _e('AI Provider', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <select name="api_provider" id="api_provider" class="regular-text">
                                <option value="openrouter" <?php selected($api_provider, 'openrouter'); ?>>OpenRouter (All Latest Models)</option>
                                <option value="openai" <?php selected($api_provider, 'openai'); ?>>OpenAI (GPT-4 Vision)</option>
                                <option value="claude" <?php selected($api_provider, 'claude'); ?>>Anthropic (Claude 3)</option>
                                <option value="gemini" <?php selected($api_provider, 'gemini'); ?>>Google (Gemini Pro Vision)</option>
                            </select>
                            <p class="description">
                                <?php _e('Select your preferred AI provider for design analysis.', 'figma-wp-converter'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="api_key"><?php _e('API Key', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <input type="password" 
                                   name="api_key" 
                                   id="api_key" 
                                   class="regular-text" 
                                   placeholder="<?php echo !empty($api_key_masked) ? $api_key_masked : __('Enter your API key', 'figma-wp-converter'); ?>"
                                   autocomplete="new-password">
                            <button type="button" id="toggle-api-key" class="button button-secondary">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                            <p class="description" id="api-key-help">
                                <!-- Dynamic help text based on provider -->
                            </p>
                        </td>
                    </tr>
                    
                    <tr id="openrouter-model-row" style="display: none;">
                        <th scope="row">
                            <label for="openrouter_model"><?php _e('OpenRouter Model', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <div id="model-selector">
                                <select name="openrouter_model" id="openrouter_model" class="regular-text">
                                    <option value="">Loading models...</option>
                                </select>
                                <button type="button" id="refresh-models" class="button button-secondary">
                                    <span class="dashicons dashicons-update"></span>
                                </button>
                            </div>
                            <div id="manual-model-input" style="display: none; margin-top: 10px;">
                                <input type="text" 
                                       name="openrouter_model_manual" 
                                       id="openrouter_model_manual" 
                                       class="regular-text" 
                                       placeholder="e.g., mistralai/pixtral-12b-2409">
                                <p class="description">
                                    <?php _e('Copy model ID from', 'figma-wp-converter'); ?> 
                                    <a href="https://openrouter.ai/models" target="_blank">OpenRouter Models</a>
                                </p>
                            </div>
                            <div style="margin-top: 10px;">
                                <label>
                                    <input type="checkbox" id="use-manual-model"> 
                                    <?php _e('Enter model manually', 'figma-wp-converter'); ?>
                                </label>
                            </div>
                            <p class="description">
                                <?php _e('Select the vision model to use for design analysis. Recommended: Mistral Pixtral or GPT-4V.', 'figma-wp-converter'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="figma_token"><?php _e('Figma Access Token', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <input type="password" 
                                   name="figma_token" 
                                   id="figma_token" 
                                   class="regular-text" 
                                   placeholder="<?php echo !empty($figma_token_masked) ? $figma_token_masked : __('Enter your Figma access token', 'figma-wp-converter'); ?>"
                                   autocomplete="new-password">
                            <button type="button" id="toggle-figma-token" class="button button-secondary">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                            <p class="description">
                                <?php _e('Required for Figma MCP integration and design data extraction.', 'figma-wp-converter'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="enable_cross_validation"><?php _e('Cross-Validation', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_cross_validation" id="enable_cross_validation" value="1" checked>
                                <?php _e('Cross-validate AI analysis with Figma design data', 'figma-wp-converter'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Compares AI screenshot analysis with actual Figma design tokens for maximum accuracy.', 'figma-wp-converter'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="test_connections"><?php _e('Test Connections', 'figma-wp-converter'); ?></label>
                        </th>
                        <td>
                            <button type="button" id="test-api-connection" class="button button-secondary">
                                <?php _e('Test AI API', 'figma-wp-converter'); ?>
                            </button>
                            <button type="button" id="test-figma-connection" class="button button-secondary" style="margin-left: 10px;">
                                <?php _e('Test Figma/MCP', 'figma-wp-converter'); ?>
                            </button>
                            <div id="test-results" style="margin-top: 10px;"></div>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary" id="save-settings">
                        <?php _e('Save Settings', 'figma-wp-converter'); ?>
                    </button>
                </p>
                
                <?php wp_nonce_field('figma_wp_settings', 'settings_nonce'); ?>
            </form>
        </div>
        
        <div class="settings-section">
            <h2><?php _e('How to Get API Keys & Tokens', 'figma-wp-converter'); ?></h2>
            
            <div class="api-instructions">
                <div class="provider-instructions" id="openrouter-instructions">
                    <h3>OpenRouter (All Latest Models)</h3>
                    <ol>
                        <li>Visit <a href="https://openrouter.ai/keys" target="_blank">OpenRouter API Keys</a></li>
                        <li>Sign in or create an account</li>
                        <li>Click "Create Key"</li>
                        <li>Name your key (e.g., "Figma to WordPress")</li>
                        <li>Copy the key and paste it above</li>
                    </ol>
                    <p class="note">
                        <strong>Best Choice:</strong> Access to GPT-4V, Claude 3.5 Sonnet, Gemini 1.5 Pro, and other latest vision models. 
                        Competitive pricing with pay-per-use model.
                    </p>
                    <div class="helpful-links">
                        <h4>Helpful Links:</h4>
                        <ul>
                            <li><a href="https://openrouter.ai/models" target="_blank">📊 Browse All Models</a></li>
                            <li><a href="https://openrouter.ai/docs" target="_blank">📖 API Documentation</a></li>
                            <li><a href="https://openrouter.ai/activity" target="_blank">💰 Usage & Billing</a></li>
                            <li><a href="https://openrouter.ai/models?supported_parameters=vision" target="_blank">👁️ Vision Models Only</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="provider-instructions" id="openai-instructions" style="display: none;">
                    <h3>OpenAI (GPT-4 Vision)</h3>
                    <ol>
                        <li>Visit <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a></li>
                        <li>Sign in or create an account</li>
                        <li>Click "Create new secret key"</li>
                        <li>Name your key (e.g., "Figma to WordPress")</li>
                        <li>Copy the key and paste it above</li>
                    </ol>
                    <p class="note">
                        <strong>Note:</strong> GPT-4 Vision API access requires a paid OpenAI account. 
                        Pricing is approximately $0.01-0.03 per screenshot analyzed.
                    </p>
                    <div class="helpful-links">
                        <h4>Helpful Links:</h4>
                        <ul>
                            <li><a href="https://platform.openai.com/api-keys" target="_blank">🔑 API Keys</a></li>
                            <li><a href="https://platform.openai.com/docs/guides/vision" target="_blank">📖 Vision Guide</a></li>
                            <li><a href="https://platform.openai.com/usage" target="_blank">💰 Usage & Billing</a></li>
                            <li><a href="https://openai.com/pricing" target="_blank">💲 Pricing</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="provider-instructions" id="claude-instructions" style="display: none;">
                    <h3>Anthropic (Claude 3)</h3>
                    <ol>
                        <li>Visit <a href="https://console.anthropic.com/" target="_blank">Anthropic Console</a></li>
                        <li>Sign in or create an account</li>
                        <li>Go to API Keys section</li>
                        <li>Click "Create Key"</li>
                        <li>Copy the key and paste it above</li>
                    </ol>
                    <p class="note">
                        <strong>Note:</strong> Claude 3 Vision requires API access. 
                        Pricing varies based on model (Opus, Sonnet, Haiku).
                    </p>
                    <div class="helpful-links">
                        <h4>Helpful Links:</h4>
                        <ul>
                            <li><a href="https://console.anthropic.com/" target="_blank">🔑 Console & Keys</a></li>
                            <li><a href="https://docs.anthropic.com/en/docs/vision" target="_blank">📖 Vision Guide</a></li>
                            <li><a href="https://console.anthropic.com/settings/usage" target="_blank">💰 Usage & Billing</a></li>
                            <li><a href="https://www.anthropic.com/pricing" target="_blank">💲 Pricing</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="provider-instructions" id="gemini-instructions" style="display: none;">
                    <h3>Google (Gemini Pro Vision)</h3>
                    <ol>
                        <li>Visit <a href="https://makersuite.google.com/app/apikey" target="_blank">Google AI Studio</a></li>
                        <li>Sign in with your Google account</li>
                        <li>Click "Get API key"</li>
                        <li>Create a new API key or use existing</li>
                        <li>Copy the key and paste it above</li>
                    </ol>
                    <p class="note">
                        <strong>Note:</strong> Gemini Pro Vision has a free tier with generous limits.
                        Paid tiers available for higher usage.
                    </p>
                    <div class="helpful-links">
                        <h4>Helpful Links:</h4>
                        <ul>
                            <li><a href="https://makersuite.google.com/app/apikey" target="_blank">🔑 API Keys</a></li>
                            <li><a href="https://ai.google.dev/docs/vision" target="_blank">📖 Vision Guide</a></li>
                            <li><a href="https://console.cloud.google.com/apis/api/generativelanguage.googleapis.com/quotas" target="_blank">💰 Quotas & Usage</a></li>
                            <li><a href="https://ai.google.dev/pricing" target="_blank">💲 Pricing</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="provider-instructions" id="figma-instructions">
                    <h3>Figma Access Token</h3>
                    <ol>
                        <li>Open Figma and go to Settings (click your profile picture)</li>
                        <li>Scroll down to "Personal access tokens"</li>
                        <li>Click "Create new token"</li>
                        <li>Name it (e.g., "WordPress Plugin")</li>
                        <li>Set expiration (recommended: 90 days)</li>
                        <li>Copy the token and paste it above</li>
                    </ol>
                    <p class="note">
                        <strong>Note:</strong> Free Figma accounts have limited API access. 
                        Professional accounts get higher rate limits and advanced features.
                    </p>
                    <div class="helpful-links">
                        <h4>Helpful Links:</h4>
                        <ul>
                            <li><a href="https://www.figma.com/developers/api#authentication" target="_blank">🔑 Token Guide</a></li>
                            <li><a href="https://www.figma.com/developers/api" target="_blank">📖 API Documentation</a></li>
                            <li><a href="https://help.figma.com/hc/en-us/articles/8085703771159-Manage-personal-access-tokens" target="_blank">🛠️ Token Management</a></li>
                            <li><a href="https://www.figma.com/developers/api#rate-limiting" target="_blank">⚡ Rate Limits</a></li>
                        </ul>
                    </div>
                    
                    <h4>Figma MCP Server Setup (Optional)</h4>
                    <p>For enhanced performance, you can run a local Figma MCP server:</p>
                    <ol>
                        <li>Install: <code>npm install -g @tothienbao6a0/figma-mcp-server</code></li>
                        <li>Run: <code>figma-mcp-server --port 3000 --token YOUR_FIGMA_TOKEN</code></li>
                        <li>The plugin will automatically detect and use the MCP server</li>
                    </ol>
                    <div class="helpful-links">
                        <h4>MCP Links:</h4>
                        <ul>
                            <li><a href="https://www.npmjs.com/package/@tothienbao6a0/figma-mcp-server" target="_blank">📦 MCP Server Package</a></li>
                            <li><a href="https://modelcontextprotocol.io/" target="_blank">📖 About MCP Protocol</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="settings-section">
            <h2><?php _e('Advanced Settings', 'figma-wp-converter'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="enable_cache"><?php _e('Enable Analysis Cache', 'figma-wp-converter'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="enable_cache" id="enable_cache" value="1" checked>
                            <?php _e('Cache design analysis results to reduce API calls', 'figma-wp-converter'); ?>
                        </label>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="analysis_detail"><?php _e('Analysis Detail Level', 'figma-wp-converter'); ?></label>
                    </th>
                    <td>
                        <select name="analysis_detail" id="analysis_detail">
                            <option value="basic">Basic - Fast generation, standard accuracy</option>
                            <option value="detailed" selected>Detailed - Balanced speed and accuracy</option>
                            <option value="comprehensive">Comprehensive - Highest accuracy, slower</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<style>
.figma-wp-settings {
    max-width: 900px;
}

.settings-container {
    background: white;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.settings-section {
    padding: 20px;
    border-bottom: 1px solid #eee;
}

.settings-section:last-child {
    border-bottom: none;
}

.settings-section h2 {
    margin-top: 0;
    color: #23282d;
}

.form-table th {
    width: 200px;
}

.api-instructions {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 5px;
    margin-top: 15px;
}

.provider-instructions {
    line-height: 1.8;
}

.provider-instructions h3 {
    margin-top: 0;
    color: #0073aa;
}

.provider-instructions ol {
    margin-left: 20px;
}

.provider-instructions .note {
    background: #fff;
    padding: 10px;
    border-left: 4px solid #ffb900;
    margin-top: 15px;
}

#toggle-api-key {
    vertical-align: middle;
}

#test-result {
    display: inline-block;
    font-weight: 500;
}

#test-results .success {
    color: #46b450;
    font-weight: 500;
}

#test-results .error {
    color: #dc3232;
    font-weight: 500;
}

#test-results .testing {
    color: #0073aa;
    font-weight: 500;
}

.description {
    color: #666;
    font-style: italic;
}

.helpful-links {
    background: #f0f8ff;
    border: 1px solid #c3d9ff;
    border-radius: 6px;
    padding: 15px;
    margin-top: 15px;
}

.helpful-links h4 {
    margin-top: 0;
    margin-bottom: 10px;
    color: #0073aa;
    font-size: 14px;
}

.helpful-links ul {
    margin: 0;
    padding-left: 20px;
}

.helpful-links li {
    margin-bottom: 5px;
}

.helpful-links a {
    text-decoration: none;
    color: #0073aa;
    font-size: 13px;
}

.helpful-links a:hover {
    text-decoration: underline;
}

#model-selector {
    display: flex;
    align-items: center;
    gap: 10px;
}

#refresh-models {
    padding: 6px 10px;
}

#refresh-models .dashicons {
    font-size: 14px;
    line-height: 1;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Toggle API key visibility
    $('#toggle-api-key').on('click', function() {
        const input = $('#api_key');
        const icon = $(this).find('.dashicons');
        
        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            input.attr('type', 'password');
            icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    });
    
    // Toggle Figma token visibility
    $('#toggle-figma-token').on('click', function() {
        const input = $('#figma_token');
        const icon = $(this).find('.dashicons');
        
        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            input.attr('type', 'password');
            icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    });
    
    // Update help text based on provider
    function updateProviderHelp() {
        const provider = $('#api_provider').val();
        const helps = {
            'openrouter': 'Enter your OpenRouter API key. Access all latest vision models including GPT-4V, Claude 3, Gemini Pro, etc.',
            'openai': 'Enter your OpenAI API key. Must have GPT-4 Vision access.',
            'claude': 'Enter your Anthropic API key with Claude 3 Vision access.',
            'gemini': 'Enter your Google AI Studio API key for Gemini Pro Vision.'
        };
        
        $('#api-key-help').text(helps[provider]);
        
        // Show/hide OpenRouter model selection
        if (provider === 'openrouter') {
            $('#openrouter-model-row').show();
            loadOpenRouterModels();
        } else {
            $('#openrouter-model-row').hide();
        }
        
        // Show corresponding instructions
        $('.provider-instructions').hide();
        $('#' + provider + '-instructions').show();
    }
    
    // Load OpenRouter models
    function loadOpenRouterModels() {
        const apiKey = $('#api_key').val();
        if (!apiKey) {
            $('#openrouter_model').html('<option value="">Enter API key first</option>');
            return;
        }
        
        $('#openrouter_model').html('<option value="">Loading models...</option>');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'load_openrouter_models',
                api_key: apiKey,
                nonce: '<?php echo wp_create_nonce('figma_wp_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    let options = '<option value="">Select a model...</option>';
                    
                    // Add recommended models first
                    options += '<optgroup label="🏆 Recommended for Design Analysis">';
                    const recommended = response.data.filter(m => 
                        m.id.includes('mistral') && m.id.includes('pixtral') ||
                        m.id.includes('gpt-4') && m.id.includes('vision') ||
                        m.id.includes('claude-3') && m.id.includes('vision')
                    );
                    recommended.forEach(model => {
                        options += `<option value="${model.id}">${model.name} - $${model.pricing.prompt}</option>`;
                    });
                    options += '</optgroup>';
                    
                    // Add all other vision models
                    options += '<optgroup label="👁️ All Vision Models">';
                    response.data.forEach(model => {
                        if (!recommended.find(r => r.id === model.id)) {
                            options += `<option value="${model.id}">${model.name} - $${model.pricing.prompt}</option>`;
                        }
                    });
                    options += '</optgroup>';
                    
                    $('#openrouter_model').html(options);
                    
                    // Set default to Mistral Pixtral if available
                    const defaultModel = response.data.find(m => m.id.includes('mistral') && m.id.includes('pixtral'));
                    if (defaultModel) {
                        $('#openrouter_model').val(defaultModel.id);
                    }
                } else {
                    $('#openrouter_model').html('<option value="">Failed to load models</option>');
                }
            },
            error: function() {
                $('#openrouter_model').html('<option value="">Error loading models</option>');
            }
        });
    }
    
    // Manual model input toggle
    $('#use-manual-model').on('change', function() {
        if ($(this).is(':checked')) {
            $('#model-selector').hide();
            $('#manual-model-input').show();
        } else {
            $('#model-selector').show();
            $('#manual-model-input').hide();
        }
    });
    
    // Refresh models button
    $('#refresh-models').on('click', function() {
        loadOpenRouterModels();
    });
    
    $('#api_provider').on('change', updateProviderHelp);
    updateProviderHelp();
    
    // Test API connection
    $('#test-api-connection').on('click', function() {
        const button = $(this);
        const resultsDiv = $('#test-results');
        const apiKey = $('#api_key').val();
        const provider = $('#api_provider').val();
        
        if (!apiKey) {
            resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> Please enter an API key first</span>');
            return;
        }
        
        button.prop('disabled', true).text('Testing...');
        resultsDiv.html('<span class="testing">Testing AI API connection...</span>');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'test_ai_connection',
                api_provider: provider,
                api_key: apiKey,
                nonce: '<?php echo wp_create_nonce('figma_wp_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    resultsDiv.html('<span class="success"><span class="dashicons dashicons-yes"></span> AI API connection successful!</span>');
                } else {
                    resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> AI API failed: ' + response.data.message + '</span>');
                }
            },
            error: function() {
                resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> AI API test failed due to server error</span>');
            },
            complete: function() {
                button.prop('disabled', false).text('Test AI API');
            }
        });
    });
    
    // Test Figma/MCP connection
    $('#test-figma-connection').on('click', function() {
        const button = $(this);
        const resultsDiv = $('#test-results');
        const figmaToken = $('#figma_token').val();
        
        if (!figmaToken) {
            resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> Please enter a Figma token first</span>');
            return;
        }
        
        button.prop('disabled', true).text('Testing...');
        resultsDiv.html('<span class="testing">Testing Figma/MCP connection...</span>');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'test_figma_connection',
                figma_token: figmaToken,
                nonce: '<?php echo wp_create_nonce('figma_wp_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    const source = response.data.source || 'API';
                    resultsDiv.html('<span class="success"><span class="dashicons dashicons-yes"></span> Figma connection successful via ' + source.toUpperCase() + '!</span>');
                } else {
                    resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> Figma failed: ' + response.data.message + '</span>');
                }
            },
            error: function() {
                resultsDiv.html('<span class="error"><span class="dashicons dashicons-no"></span> Figma test failed due to server error</span>');
            },
            complete: function() {
                button.prop('disabled', false).text('Test Figma/MCP');
            }
        });
    });
    
    // Save settings
    $('#api-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        const button = $('#save-settings');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Saving...');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'save_api_settings',
                api_provider: $('#api_provider').val(),
                api_key: $('#api_key').val(),
                figma_token: $('#figma_token').val(),
                openrouter_model: $('#openrouter_model').val(),
                openrouter_model_manual: $('#openrouter_model_manual').val(),
                nonce: '<?php echo wp_create_nonce('figma_wp_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    button.text('Saved!').addClass('button-success');
                    setTimeout(function() {
                        button.prop('disabled', false).text(originalText).removeClass('button-success');
                    }, 2000);
                } else {
                    alert('Failed to save settings: ' + response.data.message);
                    button.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                alert('Failed to save settings due to server error');
                button.prop('disabled', false).text(originalText);
            }
        });
    });
});
</script>
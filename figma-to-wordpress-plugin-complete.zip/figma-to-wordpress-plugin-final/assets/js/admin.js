/**
 * Figma to WordPress Admin JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';

    // Global variables
    let uploadedScreenshots = [];
    let projectId = null;
    
    // Initialize the plugin
    init();
    
    function init() {
        bindEvents();
        setupFormValidation();
        initializeScreenshotUpload();
        setupProgressTracking();
    }
    
    function bindEvents() {
        // Form field changes
        $('#project_name, #figma_url').on('input', updateGenerationSummary);
        $('#business_type').on('change', updateGenerationSummary);
        $('input[name="sections[]"]').on('change', updateGenerationSummary);
        
        // Figma URL validation
        $('#figma_url').on('blur', validateFigmaUrl);
        
        // Screenshot upload
        $('#select-screenshots').on('click', function(e) {
            console.log('Select screenshots button clicked');
            e.preventDefault();
            triggerFileSelection();
        });
        $('#screenshot-files').on('change', handleFileSelection);
        
        // Theme generation
        $('#generate-theme').on('click', generateTheme);
        
        // Drag and drop
        setupDragAndDrop();
    }
    
    function setupFormValidation() {
        // Real-time validation
        $('#project_name').on('input', function() {
            const name = $(this).val().trim();
            if (name.length >= 3) {
                markFieldValid($(this));
            } else {
                markFieldInvalid($(this), figmaWP.project_name_error || 'Project name must be at least 3 characters');
            }
            checkFormCompletion();
        });
    }
    
    function markFieldValid(field) {
        field.removeClass('error').addClass('valid');
        field.next('.error-message').remove();
    }
    
    function markFieldInvalid(field, message) {
        field.removeClass('valid').addClass('error');
        if (!field.next('.error-message').length) {
            field.after('<div class="error-message">' + message + '</div>');
        }
    }
    
    function validateFigmaUrl() {
        const url = $('#figma_url').val();
        const urlField = $('#figma_url');
        const validationDiv = $('#figma-url-validation');
        
        if (!url) {
            validationDiv.removeClass('success error').empty();
            return;
        }
        
        validationDiv.html('<span class="spinner is-active"></span> Validating URL...');
        
        $.ajax({
            url: figmaWP.ajax_url,
            method: 'POST',
            data: {
                action: 'validate_figma_url',
                figma_url: url,
                nonce: figmaWP.nonce
            },
            success: function(response) {
                if (response.success) {
                    validationDiv.removeClass('error').addClass('success')
                        .html('<span class="dashicons dashicons-yes-alt"></span> ' + response.data.message);
                    markFieldValid(urlField);
                } else {
                    validationDiv.removeClass('success').addClass('error')
                        .html('<span class="dashicons dashicons-dismiss"></span> ' + response.data.message);
                    markFieldInvalid(urlField, response.data.message);
                }
                checkFormCompletion();
            },
            error: function() {
                validationDiv.removeClass('success').addClass('error')
                    .html('<span class="dashicons dashicons-dismiss"></span> Error validating URL');
                checkFormCompletion();
            }
        });
    }
    
    function setupDragAndDrop() {
        const dropzone = $('#screenshot-dropzone');
        
        dropzone.on('dragenter dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('dragover');
        });
        
        dropzone.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
        });
        
        dropzone.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
            
            const files = e.originalEvent.dataTransfer.files;
            handleFiles(files);
        });
    }
    
    function triggerFileSelection() {
        console.log('Triggering file selection...');
        const fileInput = $('#screenshot-files')[0];
        if (fileInput) {
            fileInput.click();
        } else {
            console.error('File input not found!');
        }
    }
    
    function handleFileSelection() {
        const files = $('#screenshot-files')[0].files;
        handleFiles(files);
    }
    
    function handleFiles(files) {
        if (files.length === 0) return;
        
        // Validate files
        const validFiles = [];
        const errors = [];
        
        Array.from(files).forEach(file => {
            // Check file type
            if (!file.type.match(/^image\/(png|jpeg|jpg)$/)) {
                errors.push(file.name + ': Invalid file type. Use PNG or JPG only.');
                return;
            }
            
            // Check file size (10MB limit)
            if (file.size > 10 * 1024 * 1024) {
                errors.push(file.name + ': File too large. Maximum size is 10MB.');
                return;
            }
            
            validFiles.push(file);
        });
        
        // Show errors
        if (errors.length > 0) {
            showNotification('File Validation Errors:<br>' + errors.join('<br>'), 'error');
            return;
        }
        
        // Check total file count
        if (uploadedScreenshots.length + validFiles.length > 10) {
            showNotification('Maximum 10 screenshots allowed. You have ' + uploadedScreenshots.length + ' uploaded.', 'error');
            return;
        }
        
        // Sort files by name to maintain order
        validFiles.sort((a, b) => a.name.localeCompare(b.name));
        
        uploadScreenshots(validFiles);
    }
    
    function uploadScreenshots(files) {
        const progressBar = $('#upload-progress');
        const progressFill = progressBar.find('.progress-fill');
        const progressText = progressBar.find('.progress-text');
        
        progressBar.show();
        progressFill.css('width', '0%');
        
        // Generate project ID if not exists
        if (!projectId) {
            projectId = 'project_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
        
        const formData = new FormData();
        formData.append('action', 'upload_screenshot');
        formData.append('nonce', figmaWP.nonce);
        formData.append('project_id', projectId);
        
        files.forEach((file, index) => {
            formData.append('screenshot_' + index, file);
        });
        
        $.ajax({
            url: figmaWP.ajax_url,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = (e.loaded / e.total) * 100;
                        progressFill.css('width', percentComplete + '%');
                        progressText.text('Uploading... ' + Math.round(percentComplete) + '%');
                    }
                });
                return xhr;
            },
            success: function(response) {
                progressBar.hide();
                
                if (response.success) {
                    console.log('Upload successful:', response.data);
                    uploadedScreenshots = uploadedScreenshots.concat(response.data.files);
                    console.log('Updated uploadedScreenshots:', uploadedScreenshots);
                    displayUploadedScreenshots();
                    showNotification(response.data.message, 'success');
                    updateGenerationSummary();
                    checkFormCompletion();
                } else {
                    console.error('Upload failed:', response.data);
                    showNotification('Upload failed: ' + response.data.message, 'error');
                }
            },
            error: function() {
                progressBar.hide();
                showNotification('Upload failed due to server error', 'error');
            }
        });
    }
    
    function displayUploadedScreenshots() {
        const container = $('#uploaded-screenshots');
        container.empty();
        
        if (uploadedScreenshots.length === 0) return;
        
        container.append('<h4>Uploaded Screenshots (' + uploadedScreenshots.length + '/10)</h4>');
        
        const grid = $('<div class="screenshots-grid"></div>');
        
        uploadedScreenshots.forEach((screenshot, index) => {
            const item = $(`
                <div class="screenshot-item">
                    <div class="screenshot-preview">
                        <img src="${screenshot.url}" alt="${screenshot.name}" />
                        <div class="screenshot-overlay">
                            <button type="button" class="remove-screenshot" data-index="${index}">×</button>
                        </div>
                    </div>
                    <div class="screenshot-info">
                        <div class="screenshot-name">${screenshot.name}</div>
                        <div class="screenshot-order">Section ${index + 1}</div>
                    </div>
                </div>
            `);
            grid.append(item);
        });
        
        container.append(grid);
        
        // Bind remove events
        $('.remove-screenshot').on('click', function() {
            const index = $(this).data('index');
            removeScreenshot(index);
        });
    }
    
    function removeScreenshot(index) {
        uploadedScreenshots.splice(index, 1);
        displayUploadedScreenshots();
        updateGenerationSummary();
        checkFormCompletion();
    }
    
    function updateGenerationSummary() {
        const projectName = $('#project_name').val();
        const businessType = $('#business_type option:selected').text();
        const selectedSections = $('input[name="sections[]"]:checked').map(function() {
            return $(this).next().find('strong').text();
        }).get();
        
        $('#summary-project-name').text(projectName || '-');
        $('#summary-business-type').text(businessType || '-');
        $('#summary-screenshots').text(uploadedScreenshots.length + ' uploaded');
        $('#summary-sections').text(selectedSections.length > 0 ? selectedSections.join(', ') : '-');
    }
    
    function checkFormCompletion() {
        const projectName = $('#project_name').val().trim();
        const figmaUrl = $('#figma_url').val().trim();
        const hasScreenshots = uploadedScreenshots.length > 0;
        const hasValidUrl = $('#figma_url').hasClass('valid');
        
        const isComplete = projectName.length >= 3 && figmaUrl && hasScreenshots && hasValidUrl;
        
        $('#generate-theme').prop('disabled', !isComplete);
        
        if (isComplete) {
            $('#generate-theme').removeClass('disabled').addClass('ready');
        } else {
            $('#generate-theme').removeClass('ready').addClass('disabled');
        }
    }
    
    function generateTheme() {
        const button = $('#generate-theme');
        const buttonText = button.find('.button-text');
        const buttonSpinner = button.find('.button-spinner');
        
        // Disable button and show spinner
        button.prop('disabled', true);
        buttonText.hide();
        buttonSpinner.show();
        
        // Show progress steps
        $('#generation-progress').show();
        updateProgressStep('analyzing');
        
        // Collect form data
        const formData = {
            action: 'process_figma_conversion',
            nonce: figmaWP.nonce,
            project_name: $('#project_name').val(),
            figma_url: $('#figma_url').val(),
            business_type: $('#business_type').val(),
            color_scheme: $('#color_scheme').val(),
            sections: $('input[name="sections[]"]:checked').map(function() {
                return $(this).val();
            }).get(),
            project_id: projectId,
            screenshots: uploadedScreenshots
        };
        
        // Simulate progress steps
        setTimeout(() => updateProgressStep('extracting'), 2000);
        setTimeout(() => updateProgressStep('generating'), 4000);
        setTimeout(() => updateProgressStep('packaging'), 6000);
        
        $.ajax({
            url: figmaWP.ajax_url,
            method: 'POST',
            data: formData,
            timeout: 120000, // 2 minutes timeout
            success: function(response) {
                if (response.success) {
                    showGenerationSuccess(response.data);
                } else {
                    showGenerationError(response.data);
                }
            },
            error: function(xhr, status, error) {
                let message = 'Theme generation failed due to server error.';
                if (status === 'timeout') {
                    message = 'Theme generation timed out. Please try again.';
                }
                showGenerationError({message: message});
            },
            complete: function() {
                // Re-enable button
                button.prop('disabled', false);
                buttonText.show();
                buttonSpinner.hide();
                $('#generation-progress').hide();
            }
        });
    }
    
    function updateProgressStep(step) {
        $('.progress-step').removeClass('active completed');
        
        const steps = ['analyzing', 'extracting', 'generating', 'packaging'];
        const currentIndex = steps.indexOf(step);
        
        steps.forEach((stepName, index) => {
            const stepEl = $('.progress-step[data-step="' + stepName + '"]');
            if (index < currentIndex) {
                stepEl.addClass('completed');
            } else if (index === currentIndex) {
                stepEl.addClass('active');
            }
        });
    }
    
    function showGenerationSuccess(data) {
        const resultDiv = $('#generation-result');
        const html = `
            <div class="generation-success">
                <div class="success-icon">🎉</div>
                <h3>Theme Generated Successfully!</h3>
                <p>Your WordPress theme has been created and is ready to download.</p>
                
                <div class="result-actions">
                    <a href="${data.download_url}" class="button button-primary button-large" download>
                        <span class="dashicons dashicons-download"></span>
                        Download Theme ZIP
                    </a>
                    ${data.preview_url ? `<a href="${data.preview_url}" class="button button-secondary" target="_blank">Preview Theme</a>` : ''}
                </div>
                
                <div class="next-steps">
                    <h4>Next Steps:</h4>
                    <ol>
                        <li>Download the theme ZIP file</li>
                        <li>Go to your WordPress admin: Appearance → Themes</li>
                        <li>Click "Add New" → "Upload Theme"</li>
                        <li>Upload and activate your new theme</li>
                        <li>Customize with your content and images</li>
                    </ol>
                </div>
                
                <div class="result-info">
                    <p><strong>Project ID:</strong> ${data.project_id}</p>
                    <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
                </div>
            </div>
        `;
        
        resultDiv.html(html).show();
        showNotification('Theme generated successfully!', 'success');
        
        // Scroll to results
        $('html, body').animate({
            scrollTop: resultDiv.offset().top - 50
        }, 500);
    }
    
    function showGenerationError(data) {
        const resultDiv = $('#generation-result');
        const html = `
            <div class="generation-error">
                <div class="error-icon">❌</div>
                <h3>Theme Generation Failed</h3>
                <p>${data.message}</p>
                
                ${data.errors ? `
                    <div class="error-details">
                        <h4>Error Details:</h4>
                        <ul>
                            ${data.errors.map(error => `<li>${error}</li>`).join('')}
                        </ul>
                    </div>
                ` : ''}
                
                <div class="error-actions">
                    <button type="button" class="button button-primary" id="retry-generation">
                        Try Again
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=figma-wp-instructions'); ?>" class="button button-secondary">
                        View Instructions
                    </a>
                </div>
            </div>
        `;
        
        resultDiv.html(html).show();
        showNotification('Theme generation failed. Please check the errors and try again.', 'error');
        
        // Bind retry button
        $('#retry-generation').on('click', generateTheme);
    }
    
    function setupProgressTracking() {
        // Track form completion progress
        const totalSteps = 4;
        let completedSteps = 0;
        let isUpdatingProgress = false;
        
        function updateProgress() {
            // Prevent recursive calls
            if (isUpdatingProgress) {
                return;
            }
            
            isUpdatingProgress = true;
            
            try {
                const projectComplete = $('#project_name').val().length >= 3 && $('#figma_url').hasClass('valid');
                const screenshotsComplete = uploadedScreenshots.length > 0;
                const sectionsComplete = $('input[name="sections[]"]:checked').length > 0;
                
                completedSteps = 0;
                if (projectComplete) completedSteps++;
                if (screenshotsComplete) completedSteps++;
                if (sectionsComplete) completedSteps++;
                if (completedSteps === 3) completedSteps++; // Ready to generate
                
                // Update step indicators
                $('.figma-wp-card').each(function(index) {
                    const step = index + 1;
                    const stepNumber = $(this).find('.step-number');
                    
                    if (step <= completedSteps) {
                        stepNumber.addClass('completed');
                    } else {
                        stepNumber.removeClass('completed');
                    }
                    
                    if (step === completedSteps + 1) {
                        stepNumber.addClass('current');
                    } else {
                        stepNumber.removeClass('current');
                    }
                });
            } finally {
                isUpdatingProgress = false;
            }
        }
        
        // Update progress on form changes (throttled to prevent infinite loops)
        let progressTimeout;
        $(document).on('input change', 'form input, form select', function() {
            clearTimeout(progressTimeout);
            progressTimeout = setTimeout(updateProgress, 100);
        });
        
        // Periodic update (less frequent)
        setInterval(updateProgress, 5000);
    }
    
    function initializeScreenshotUpload() {
        // Initialize screenshot upload area
        const dropzone = $('#screenshot-dropzone');
        
        // Only trigger on dropzone area clicks, not button clicks
        dropzone.on('click', function(e) {
            // Don't trigger if clicking the button itself
            if (!$(e.target).is('#select-screenshots') && !$(e.target).closest('#select-screenshots').length) {
                console.log('Dropzone clicked');
                triggerFileSelection();
            }
        });
        
        // Ensure the file input exists
        if ($('#screenshot-files').length === 0) {
            console.error('Screenshot file input not found in DOM');
        }
    }
    
    function showNotification(message, type) {
        // Remove existing notifications
        $('.figma-wp-notification').remove();
        
        const notification = $(`
            <div class="figma-wp-notification ${type}">
                <div class="notification-content">
                    <span class="notification-icon">
                        ${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}
                    </span>
                    <span class="notification-message">${message}</span>
                    <button class="notification-close">×</button>
                </div>
            </div>
        `);
        
        $('body').append(notification);
        
        setTimeout(() => {
            notification.addClass('show');
        }, 100);
        
        // Auto-hide after 5 seconds for success, 10 seconds for error
        const hideTimeout = type === 'success' ? 5000 : 10000;
        setTimeout(() => {
            hideNotification(notification);
        }, hideTimeout);
        
        // Manual close
        notification.find('.notification-close').on('click', function() {
            hideNotification(notification);
        });
    }
    
    function hideNotification(notification) {
        notification.removeClass('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }
});

// Additional CSS for notifications and UI enhancements
const additionalCSS = `
<style>
.figma-wp-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 999999;
    max-width: 400px;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
}

.figma-wp-notification.show {
    opacity: 1;
    transform: translateX(0);
}

.figma-wp-notification .notification-content {
    background: white;
    border-radius: 6px;
    padding: 15px 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    border-left: 4px solid;
    display: flex;
    align-items: center;
    gap: 10px;
}

.figma-wp-notification.success .notification-content {
    border-left-color: #28a745;
}

.figma-wp-notification.error .notification-content {
    border-left-color: #dc3545;
}

.figma-wp-notification.info .notification-content {
    border-left-color: #17a2b8;
}

.notification-close {
    background: none;
    border: none;
    font-size: 20px;
    cursor: pointer;
    opacity: 0.5;
    margin-left: auto;
}

.notification-close:hover {
    opacity: 1;
}

.form-field.error input,
.form-field.error select {
    border-color: #dc3545;
    box-shadow: 0 0 0 1px rgba(220, 53, 69, 0.25);
}

.form-field.valid input,
.form-field.valid select {
    border-color: #28a745;
    box-shadow: 0 0 0 1px rgba(40, 167, 69, 0.25);
}

.error-message {
    color: #dc3545;
    font-size: 12px;
    margin-top: 5px;
}

.validation-message.success {
    color: #28a745;
    font-size: 14px;
    margin-top: 5px;
}

.validation-message.error {
    color: #dc3545;
    font-size: 14px;
    margin-top: 5px;
}

.screenshots-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.screenshot-item {
    border: 1px solid #ddd;
    border-radius: 6px;
    overflow: hidden;
    background: white;
}

.screenshot-preview {
    position: relative;
    height: 120px;
    overflow: hidden;
}

.screenshot-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.screenshot-overlay {
    position: absolute;
    top: 0;
    right: 0;
    background: rgba(0,0,0,0.7);
    opacity: 0;
    transition: opacity 0.3s;
}

.screenshot-item:hover .screenshot-overlay {
    opacity: 1;
}

.remove-screenshot {
    background: #dc3545;
    color: white;
    border: none;
    width: 30px;
    height: 30px;
    cursor: pointer;
    font-size: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.screenshot-info {
    padding: 10px;
}

.screenshot-name {
    font-weight: bold;
    font-size: 12px;
    margin-bottom: 3px;
}

.screenshot-order {
    font-size: 11px;
    color: #666;
}

.step-number.completed {
    background: #28a745;
}

.step-number.current {
    background: #ffc107;
    color: #000;
}

.progress-step {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
    opacity: 0.5;
    transition: all 0.3s ease;
}

.progress-step.active {
    opacity: 1;
    font-weight: bold;
}

.progress-step.completed {
    opacity: 0.8;
}

.step-indicator {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #ddd;
    position: relative;
}

.progress-step.active .step-indicator {
    background: #0073aa;
    animation: pulse 1.5s infinite;
}

.progress-step.completed .step-indicator {
    background: #28a745;
}

.progress-step.completed .step-indicator:after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 10px;
    font-weight: bold;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

.generation-success,
.generation-error {
    text-align: center;
    padding: 40px 20px;
    background: white;
    border-radius: 8px;
    border: 1px solid #ddd;
}

.success-icon,
.error-icon {
    font-size: 48px;
    margin-bottom: 20px;
}

.result-actions {
    margin: 30px 0;
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

.next-steps {
    background: #f8f9fa;
    border-radius: 6px;
    padding: 20px;
    margin: 20px 0;
    text-align: left;
}

.next-steps ol {
    margin: 10px 0 0 20px;
}

.result-info {
    margin-top: 20px;
    font-size: 14px;
    color: #666;
}

.error-details {
    background: #f8f9fa;
    border-radius: 6px;
    padding: 15px;
    margin: 15px 0;
    text-align: left;
}

.error-details ul {
    margin: 10px 0 0 20px;
}
</style>
`;

// Inject additional CSS
jQuery(document).ready(function($) {
    $('head').append(additionalCSS);
});
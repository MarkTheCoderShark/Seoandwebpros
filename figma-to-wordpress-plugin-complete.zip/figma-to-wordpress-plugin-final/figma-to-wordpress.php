<?php
/**
 * Plugin Name: Figma to WordPress Theme Converter
 * Plugin URI: https://yourwebsite.com/figma-to-wordpress
 * Description: Convert Figma designs to pixel-perfect WordPress themes with screenshot analysis and automatic theme generation.
 * Version: 2.0.0
 * Author: Figma to WordPress Team
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: figma-wp-converter
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('FWC_PLUGIN_VERSION', '2.0.0');
define('FWC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FWC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FWC_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('FWC_UPLOADS_DIR', wp_upload_dir()['basedir'] . '/figma-wp-converter/');
define('FWC_UPLOADS_URL', wp_upload_dir()['baseurl'] . '/figma-wp-converter/');

// Main plugin class
class FigmaToWordPressConverter {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_process_figma_conversion', array($this, 'process_figma_conversion'));
        add_action('wp_ajax_upload_screenshot', array($this, 'handle_screenshot_upload'));
        add_action('wp_ajax_validate_figma_url', array($this, 'validate_figma_url'));
        add_action('wp_ajax_save_api_settings', array($this, 'save_api_settings'));
        add_action('wp_ajax_test_ai_connection', array($this, 'test_ai_connection'));
        add_action('wp_ajax_test_figma_connection', array($this, 'test_figma_connection'));
        add_action('wp_ajax_load_openrouter_models', array($this, 'load_openrouter_models'));
        
        // Create uploads directory
        $this->create_uploads_directory();
        
        // Load includes
        $this->load_includes();
        
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        load_plugin_textdomain('figma-wp-converter', false, dirname(FWC_PLUGIN_BASENAME) . '/languages');
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('Figma to WordPress', 'figma-wp-converter'),
            __('Figma to WP', 'figma-wp-converter'),
            'manage_options',
            'figma-wp-converter',
            array($this, 'main_page'),
            'dashicons-admin-customizer',
            30
        );
        
        add_submenu_page(
            'figma-wp-converter',
            __('Convert Design', 'figma-wp-converter'),
            __('Convert Design', 'figma-wp-converter'),
            'manage_options',
            'figma-wp-converter',
            array($this, 'main_page')
        );
        
        add_submenu_page(
            'figma-wp-converter',
            __('Instructions', 'figma-wp-converter'),
            __('Instructions', 'figma-wp-converter'),
            'manage_options',
            'figma-wp-instructions',
            array($this, 'instructions_page')
        );
        
        add_submenu_page(
            'figma-wp-converter',
            __('Generated Themes', 'figma-wp-converter'),
            __('Generated Themes', 'figma-wp-converter'),
            'manage_options',
            'figma-wp-themes',
            array($this, 'themes_page')
        );
        
        add_submenu_page(
            'figma-wp-converter',
            __('Settings', 'figma-wp-converter'),
            __('Settings', 'figma-wp-converter'),
            'manage_options',
            'figma-wp-settings',
            array($this, 'settings_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'figma-wp') === false) {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_script(
            'figma-wp-admin',
            FWC_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'media-upload'),
            FWC_PLUGIN_VERSION,
            true
        );
        
        wp_enqueue_style(
            'figma-wp-admin',
            FWC_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            FWC_PLUGIN_VERSION
        );
        
        wp_localize_script('figma-wp-admin', 'figmaWP', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('figma_wp_nonce'),
            'uploading_text' => __('Uploading...', 'figma-wp-converter'),
            'processing_text' => __('Processing...', 'figma-wp-converter'),
            'success_text' => __('Success!', 'figma-wp-converter'),
            'error_text' => __('Error occurred', 'figma-wp-converter')
        ));
    }
    
    public function main_page() {
        include FWC_PLUGIN_DIR . 'admin/main-page.php';
    }
    
    public function instructions_page() {
        include FWC_PLUGIN_DIR . 'admin/instructions-page.php';
    }
    
    public function themes_page() {
        include FWC_PLUGIN_DIR . 'admin/themes-page.php';
    }
    
    public function settings_page() {
        include FWC_PLUGIN_DIR . 'admin/settings-page.php';
    }
    
    public function handle_screenshot_upload() {
        check_ajax_referer('figma_wp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'figma-wp-converter'));
        }
        
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $upload_overrides = array('test_form' => false);
        
        $uploaded_files = array();
        $errors = array();
        
        foreach ($_FILES as $file_key => $file) {
            if ($file['error'] === UPLOAD_ERR_OK) {
                $movefile = wp_handle_upload($file, $upload_overrides);
                
                if ($movefile && !isset($movefile['error'])) {
                    // Move to our custom directory
                    $project_id = sanitize_text_field($_POST['project_id']);
                    $project_dir = FWC_UPLOADS_DIR . $project_id . '/screenshots/';
                    
                    if (!file_exists($project_dir)) {
                        wp_mkdir_p($project_dir);
                    }
                    
                    $filename = sanitize_file_name($file['name']);
                    $destination = $project_dir . $filename;
                    
                    if (move_uploaded_file($movefile['file'], $destination)) {
                        $uploaded_files[] = array(
                            'name' => $filename,
                            'url' => FWC_UPLOADS_URL . $project_id . '/screenshots/' . $filename,
                            'path' => $destination
                        );
                    }
                } else {
                    $errors[] = $movefile['error'];
                }
            } else {
                $errors[] = sprintf(__('Upload error for %s: %s', 'figma-wp-converter'), $file['name'], $file['error']);
            }
        }
        
        if (empty($errors)) {
            wp_send_json_success(array(
                'files' => $uploaded_files,
                'message' => __('Screenshots uploaded successfully!', 'figma-wp-converter')
            ));
        } else {
            wp_send_json_error(array(
                'errors' => $errors,
                'message' => __('Some files failed to upload', 'figma-wp-converter')
            ));
        }
    }
    
    public function validate_figma_url() {
        check_ajax_referer('figma_wp_nonce', 'nonce');
        
        $figma_url = sanitize_url($_POST['figma_url']);
        
        // Basic Figma URL validation
        if (strpos($figma_url, 'figma.com/design/') !== false || strpos($figma_url, 'figma.com/file/') !== false) {
            wp_send_json_success(array(
                'message' => __('Valid Figma URL', 'figma-wp-converter'),
                'is_valid' => true
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Invalid Figma URL. Please provide a valid Figma design URL.', 'figma-wp-converter'),
                'is_valid' => false
            ));
        }
    }
    
    public function process_figma_conversion() {
        check_ajax_referer('figma_wp_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'figma-wp-converter'));
        }
        
        $project_name = sanitize_text_field($_POST['project_name']);
        $figma_url = sanitize_url($_POST['figma_url']);
        $business_type = sanitize_text_field($_POST['business_type']);
        $color_scheme = sanitize_text_field($_POST['color_scheme']);
        $sections = array_map('sanitize_text_field', $_POST['sections']);
        
        // Create project directory
        $project_id = uniqid('figma_', true);
        $project_dir = FWC_UPLOADS_DIR . $project_id . '/';
        
        if (!wp_mkdir_p($project_dir)) {
            wp_send_json_error(array(
                'message' => __('Failed to create project directory', 'figma-wp-converter')
            ));
        }
        
        // Save project data
        $project_data = array(
            'id' => $project_id,
            'name' => $project_name,
            'figma_url' => $figma_url,
            'business_type' => $business_type,
            'color_scheme' => $color_scheme,
            'sections' => $sections,
            'created_at' => current_time('mysql'),
            'status' => 'processing'
        );
        
        file_put_contents($project_dir . 'project.json', json_encode($project_data, JSON_PRETTY_PRINT));
        
        // Include theme generator
        require_once FWC_PLUGIN_DIR . 'includes/class-theme-generator.php';
        $generator = new FWC_Theme_Generator($project_data, $project_dir);
        
        // Analyze screenshots and generate theme
        $result = $generator->generate_theme();
        
        if ($result['success']) {
            // Update project status
            $project_data['status'] = 'completed';
            $project_data['theme_path'] = $result['theme_path'];
            $project_data['download_url'] = $result['download_url'];
            file_put_contents($project_dir . 'project.json', json_encode($project_data, JSON_PRETTY_PRINT));
            
            wp_send_json_success(array(
                'message' => __('Theme generated successfully!', 'figma-wp-converter'),
                'project_id' => $project_id,
                'download_url' => $result['download_url'],
                'preview_url' => $result['preview_url']
            ));
        } else {
            wp_send_json_error(array(
                'message' => $result['message'],
                'errors' => $result['errors']
            ));
        }
    }
    
    private function create_uploads_directory() {
        if (!file_exists(FWC_UPLOADS_DIR)) {
            wp_mkdir_p(FWC_UPLOADS_DIR);
            
            // Create .htaccess for security
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "<Files *.php>\n";
            $htaccess_content .= "deny from all\n";
            $htaccess_content .= "</Files>\n";
            
            file_put_contents(FWC_UPLOADS_DIR . '.htaccess', $htaccess_content);
        }
    }
    
    private function load_includes() {
        require_once FWC_PLUGIN_DIR . 'includes/class-figma-analyzer.php';
        require_once FWC_PLUGIN_DIR . 'includes/class-theme-generator.php';
        require_once FWC_PLUGIN_DIR . 'includes/class-file-handler.php';
    }
    
    public function activate() {
        $this->create_uploads_directory();
        
        // Create database table for projects
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'figma_wp_projects';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            project_id varchar(100) NOT NULL,
            project_name varchar(255) NOT NULL,
            figma_url text NOT NULL,
            business_type varchar(100),
            status varchar(50) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            theme_path text,
            download_url text,
            PRIMARY KEY (id),
            UNIQUE KEY project_id (project_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Set default options
        add_option('figma_wp_converter_version', FWC_PLUGIN_VERSION);
        add_option('figma_wp_converter_settings', array(
            'max_screenshots' => 10,
            'allowed_file_types' => array('png', 'jpg', 'jpeg'),
            'max_file_size' => 10 * 1024 * 1024, // 10MB
        ));
    }
    
    public function deactivate() {
        // Clean up temporary files older than 30 days
        $this->cleanup_old_projects(30);
    }
    
    private function cleanup_old_projects($days = 30) {
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'figma_wp_projects';
        
        $old_projects = $wpdb->get_results($wpdb->prepare(
            "SELECT project_id FROM $table_name WHERE created_at < %s",
            $cutoff_date
        ));
        
        foreach ($old_projects as $project) {
            $project_dir = FWC_UPLOADS_DIR . $project->project_id . '/';
            if (file_exists($project_dir)) {
                $this->delete_directory($project_dir);
            }
        }
        
        // Remove from database
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE created_at < %s",
            $cutoff_date
        ));
    }
    
    private function delete_directory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            is_dir($path) ? $this->delete_directory($path) : unlink($path);
        }
        
        rmdir($dir);
    }
    
    public function save_api_settings() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'figma_wp_nonce')) {
            wp_send_json_error(array('message' => 'Security verification failed'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $api_provider = sanitize_text_field($_POST['api_provider']);
        $api_key = sanitize_text_field($_POST['api_key']);
        $figma_token = sanitize_text_field($_POST['figma_token']);
        $openrouter_model = isset($_POST['openrouter_model']) ? sanitize_text_field($_POST['openrouter_model']) : '';
        $openrouter_model_manual = isset($_POST['openrouter_model_manual']) ? sanitize_text_field($_POST['openrouter_model_manual']) : '';
        
        // Save settings
        update_option('fwc_api_provider', $api_provider);
        
        // Save OpenRouter model (prefer manual input if provided)
        if ($api_provider === 'openrouter') {
            $selected_model = !empty($openrouter_model_manual) ? $openrouter_model_manual : $openrouter_model;
            update_option('fwc_openrouter_model', $selected_model);
        }
        
        // Encrypt keys before saving
        if (!empty($api_key)) {
            update_option('fwc_api_key', base64_encode($api_key));
        }
        
        if (!empty($figma_token)) {
            update_option('fwc_figma_token', base64_encode($figma_token));
        }
        
        wp_send_json_success(array('message' => 'Settings saved successfully'));
    }
    
    public function test_ai_connection() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'figma_wp_nonce')) {
            wp_send_json_error(array('message' => 'Security verification failed'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $api_provider = sanitize_text_field($_POST['api_provider']);
        $api_key = sanitize_text_field($_POST['api_key']);
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'API key is required'));
        }
        
        // Test the AI API connection
        $test_result = $this->test_ai_api_connection($api_provider, $api_key);
        
        if ($test_result['success']) {
            wp_send_json_success(array(
                'message' => 'API connection successful',
                'provider' => $api_provider
            ));
        } else {
            wp_send_json_error(array('message' => $test_result['message']));
        }
    }
    
    public function test_figma_connection() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'figma_wp_nonce')) {
            wp_send_json_error(array('message' => 'Security verification failed'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $figma_token = sanitize_text_field($_POST['figma_token']);
        
        if (empty($figma_token)) {
            wp_send_json_error(array('message' => 'Figma token is required'));
        }
        
        // Test MCP server first, then fallback to Figma API
        $test_result = $this->test_figma_mcp_connection($figma_token);
        
        if ($test_result['success']) {
            wp_send_json_success(array(
                'message' => 'Figma connection successful',
                'source' => $test_result['source']
            ));
        } else {
            wp_send_json_error(array('message' => $test_result['message']));
        }
    }
    
    private function test_ai_api_connection($provider, $api_key) {
        switch ($provider) {
            case 'openrouter':
                return $this->test_openrouter_connection($api_key);
            case 'openai':
                return $this->test_openai_connection($api_key);
            case 'claude':
                return $this->test_claude_connection($api_key);
            case 'gemini':
                return $this->test_gemini_connection($api_key);
            default:
                return array('success' => false, 'message' => 'Unknown provider');
        }
    }
    
    private function test_openrouter_connection($api_key) {
        $response = wp_remote_get('https://openrouter.ai/api/v1/models', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array('success' => true, 'message' => 'OpenRouter API connection successful');
        } elseif ($code === 401) {
            return array('success' => false, 'message' => 'Invalid API key');
        } else {
            return array('success' => false, 'message' => 'API error (code: ' . $code . ')');
        }
    }
    
    private function test_openai_connection($api_key) {
        $response = wp_remote_get('https://api.openai.com/v1/models', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array('success' => true, 'message' => 'OpenAI API connection successful');
        } elseif ($code === 401) {
            return array('success' => false, 'message' => 'Invalid API key');
        } else {
            return array('success' => false, 'message' => 'API error (code: ' . $code . ')');
        }
    }
    
    private function test_claude_connection($api_key) {
        $response = wp_remote_post('https://api.anthropic.com/v1/messages', array(
            'headers' => array(
                'x-api-key' => $api_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'claude-3-haiku-20240307',
                'max_tokens' => 10,
                'messages' => array(array('role' => 'user', 'content' => 'test'))
            )),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array('success' => true, 'message' => 'Claude API connection successful');
        } elseif ($code === 401) {
            return array('success' => false, 'message' => 'Invalid API key');
        } else {
            return array('success' => false, 'message' => 'API error (code: ' . $code . ')');
        }
    }
    
    private function test_gemini_connection($api_key) {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . $api_key;
        
        $response = wp_remote_get($url, array(
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Connection failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array('success' => true, 'message' => 'Gemini API connection successful');
        } elseif ($code === 400) {
            return array('success' => false, 'message' => 'Invalid API key');
        } else {
            return array('success' => false, 'message' => 'API error (code: ' . $code . ')');
        }
    }
    
    private function test_figma_mcp_connection($figma_token) {
        // Test MCP server first
        $mcp_endpoints = array('http://localhost:3000', 'http://127.0.0.1:3000');
        
        foreach ($mcp_endpoints as $endpoint) {
            $response = wp_remote_get($endpoint . '/mcp', array(
                'timeout' => 5,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $figma_token
                )
            ));
            
            if (!is_wp_error($response)) {
                $code = wp_remote_retrieve_response_code($response);
                if ($code === 400) { // Expected error for missing session
                    return array(
                        'success' => true, 
                        'message' => 'MCP server connection successful', 
                        'source' => 'mcp'
                    );
                }
            }
        }
        
        // Fallback to direct Figma API
        $response = wp_remote_get('https://api.figma.com/v1/me', array(
            'headers' => array(
                'X-Figma-Token' => $figma_token
            ),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Both MCP and Figma API failed: ' . $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return array(
                'success' => true, 
                'message' => 'Figma API connection successful (MCP server not available)', 
                'source' => 'api'
            );
        } elseif ($code === 403) {
            return array('success' => false, 'message' => 'Invalid Figma token');
        } else {
            return array('success' => false, 'message' => 'Figma API error (code: ' . $code . ')');
        }
    }
    
    public function load_openrouter_models() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'figma_wp_nonce')) {
            wp_send_json_error(array('message' => 'Security verification failed'));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }
        
        $api_key = sanitize_text_field($_POST['api_key']);
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => 'API key is required'));
        }
        
        $response = wp_remote_get('https://openrouter.ai/api/v1/models', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 15
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Failed to fetch models: ' . $response->get_error_message()));
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['data'])) {
            $error_msg = 'Invalid API response';
            if (isset($body['error'])) {
                $error_msg .= ': ' . $body['error']['message'];
            }
            wp_send_json_error(array('message' => $error_msg));
        }
        
        // Filter for vision models only
        $vision_models = array_filter($body['data'], function($model) {
            // Check if model supports image input
            $hasImageInput = isset($model['architecture']['input_modalities']) && 
                           in_array('image', $model['architecture']['input_modalities']);
            
            // Check if architecture contains vision/image modality
            $hasVisionModality = isset($model['architecture']['modality']) && 
                               (strpos($model['architecture']['modality'], 'image') !== false ||
                                strpos($model['architecture']['modality'], 'vision') !== false);
            
            // Check model name/id for vision keywords
            $hasVisionKeywords = stripos($model['name'], 'vision') !== false ||
                               stripos($model['id'], 'vision') !== false ||
                               stripos($model['id'], 'pixtral') !== false ||
                               stripos($model['id'], 'gpt-4') !== false ||
                               stripos($model['id'], 'gpt-5') !== false ||
                               stripos($model['id'], 'claude') !== false ||
                               stripos($model['id'], 'gemini') !== false ||
                               stripos($model['name'], 'claude') !== false ||
                               stripos($model['name'], 'gemini') !== false;
            
            return $hasImageInput || $hasVisionModality || $hasVisionKeywords;
        });
        
        // Format models for dropdown
        $formatted_models = array();
        foreach ($vision_models as $model) {
            $formatted_models[] = array(
                'id' => $model['id'],
                'name' => $model['name'],
                'pricing' => array(
                    'prompt' => number_format($model['pricing']['prompt'] * 1000000, 4) . '/1M tokens'
                )
            );
        }
        
        // Sort by name
        usort($formatted_models, function($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });
        
        wp_send_json_success($formatted_models);
    }
}

// Initialize the plugin
function figma_to_wordpress_converter() {
    return FigmaToWordPressConverter::get_instance();
}

// Start the plugin
add_action('plugins_loaded', 'figma_to_wordpress_converter');